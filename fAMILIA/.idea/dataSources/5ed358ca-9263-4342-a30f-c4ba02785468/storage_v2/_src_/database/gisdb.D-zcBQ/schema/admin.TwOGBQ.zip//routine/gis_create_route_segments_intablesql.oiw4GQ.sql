create function gis_create_route_segments_intablesql(in_route_id integer, all_ways boolean DEFAULT true) returns void
    language sql
as
$$
    --
--select createrouterelationforpoint(id, 0.5, $2) from route_points where route_id = $1;
--
delete from public."routeSegments" where "idRoute" = $1;
--
insert into "routeSegments"(
	"idRoute", "seq", "subrouteId", "source", "sourceFraction", "targetFraction", "edge", "name", "cost", "geom", "dataStr"
)
select o_route_id, o_seq, o_subroute_id, o_source, o_source_fr, o_target_fr, o_edge, o_name, o_cost, o_geom, o_data_str
from  admin.gis_create_route_segments_edge($1, $2);


$$;

alter function gis_create_route_segments_intablesql(integer, boolean) owner to postgres;

