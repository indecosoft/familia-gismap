create view v_resurse_optiuni
            ("idRes", "numeRes", "typeRes", "defaultAccessRes", id, nume, "defaultAccess", "customAccess", "idItem") as
SELECT res.id              AS "idRes",
       res.nume            AS "numeRes",
       res.type            AS "typeRes",
       res."defaultAccess" AS "defaultAccessRes",
       opr.id,
       opr.nume,
       opr."defaultAccess",
       opr."customAccess",
       opr."idItem"
FROM admin.resursa res
         JOIN admin."optiuneResursa" opr ON res.id = opr."idResursa"
ORDER BY res.type, res.nume;

alter table v_resurse_optiuni
    owner to postgres;

