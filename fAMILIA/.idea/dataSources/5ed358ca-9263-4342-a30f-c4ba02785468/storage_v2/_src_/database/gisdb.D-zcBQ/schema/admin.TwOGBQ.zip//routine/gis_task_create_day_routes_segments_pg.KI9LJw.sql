create function gis_task_create_day_routes_segments_pg(task_id integer) returns integer
    language plpgsql
as
$$
declare
 var_status text;
begin
--lock task and coresponding routes
execute 'select * from public."taskTracker" where "id" = $1 for update NOWAIT;' using task_id;
execute  'select * from public."routes" where "idTask" = $1 for update NOWAIT;' using task_id;

select "status" from public."taskTracker" where "id" = task_id into var_status;

if var_status = 'rute_end_puncte_in_retea' or var_status = 'rute_run_segmente_generate' then
	--
	execute 'select admin.gis_create_route_segments_intablesql("id") 
			FROM  public.routes where "idTask" = $1;' using task_id;
	--
	execute 'update public.routes set status = $2, time = clock_timestamp() 
	where "idTask" = $1;' using task_id, 'rute_end_segmente_generate' ;
	--
	execute 'update public."taskTracker" set status = $2, time = clock_timestamp()
	where id = $1;' using task_id, 'rute_end_segmente_generate';
	--
	return 1;
else 
	return 0;
end if;

end;

$$;

alter function gis_task_create_day_routes_segments_pg(integer) owner to postgres;

