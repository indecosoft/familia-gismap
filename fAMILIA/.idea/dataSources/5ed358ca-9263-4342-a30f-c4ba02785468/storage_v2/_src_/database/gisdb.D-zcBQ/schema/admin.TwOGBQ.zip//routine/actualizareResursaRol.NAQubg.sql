create function "actualizareResursaRol"("idRolP" integer, "idResursaP" integer, access boolean) returns void
    language plpgsql
as
$$
BEGIN
	IF NOT EXISTS(SELECT 1 FROM admin."resursaRol" WHERE "idRol" = $1 AND "idResursa" = $2) THEN
		INSERT INTO admin."resursaRol"("idRol", "idResursa", "access") VALUES ($1, $2, $3);	
	END IF;
	END;
$$;

alter function "actualizareResursaRol"(integer, integer, boolean) owner to postgres;

