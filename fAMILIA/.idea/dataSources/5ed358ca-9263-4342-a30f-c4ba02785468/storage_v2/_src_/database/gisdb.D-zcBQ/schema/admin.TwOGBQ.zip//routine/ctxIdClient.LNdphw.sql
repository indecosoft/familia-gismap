create function "ctxIdClient"() returns character varying
    language sql
as
$$
SELECT coalesce(current_setting('ctx.idClient', 't'), '0');

$$;

alter function "ctxIdClient"() owner to postgres;

