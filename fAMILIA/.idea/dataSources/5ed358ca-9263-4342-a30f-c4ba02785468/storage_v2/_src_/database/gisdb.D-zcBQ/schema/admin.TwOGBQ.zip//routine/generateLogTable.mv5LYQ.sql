create function "generateLogTable"(tablename text, tableschema text) returns void
    language plpgsql
as
$$
DECLARE
	triggerString text;
	logTableString text;
  columnsString text;
  valuesString text;
	logTableFunctionString text;
	insertUsernameString text;
	insertStampString text;
	addColumnsString text;
  dropTriggerString text;
  primaryKeyName text;
BEGIN
  select column_name into primaryKeyName from INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE table_name = '' || tablename || '' AND table_schema = '' || tableschema || '';

	IF NOT(SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='' || tableschema || '' AND table_name='' || tablename || '' AND column_name='username')) THEN
		insertUsernameString := 'ALTER TABLE ' || tableSchema || '."'  || tableName || '"
		ADD username varchar(250) DEFAULT ''''';
		EXECUTE insertUsernameString;
	end if;

	IF NOT(SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='' || tableschema || '' AND table_name='' || tablename || '' AND column_name='stamp')) THEN
		insertStampString := 'ALTER TABLE ' || tableSchema || '."'  || tableName || '"
		ADD stamp timestamp';
		EXECUTE insertStampString;
	end if;

	select array_to_string(
    	array_agg(
      	'    old."' || column_name || '" '
    	)
    , E','
  	) as values
  FROM information_schema.columns
  WHERE table_schema = '' || tableschema || '' AND table_name   = '' || tablename || '' AND column_name != 'username' AND column_name != 'stamp'
  group by table_name
	INTO valuesString;

  SELECT REPLACE(valuesString,'old.','') INTO columnsString;

	IF NOT(SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='log' AND table_name='' || tablename || '')) THEN
		SELECT
				'CREATE TABLE log."' || table_name || E'"\n(\n' ||
				array_to_string(
					array_agg(
						'    "' || column_name || '" ' ||  udt_name
						|| CASE WHEN character_maximum_length > 0 THEN'(' || character_maximum_length || ') ' ELSE ' ' END
						|| 'null'
					)
					, E',\n'
				) || E'\n);\n'
		FROM information_schema.columns
		WHERE table_schema = '' || tableschema || '' AND table_name   = '' || tablename || ''
		GROUP BY table_name
		INTO logTableString;
		EXECUTE logTableString;
	ELSE
		SELECT array_to_string(
					array_agg('ADD '
						'    "' || c1.column_name || '" ' ||  data_type
						|| CASE WHEN c1.character_maximum_length > 0 THEN'(' || c1.character_maximum_length || ') ' ELSE ' ' END
						|| 'null'
					)
					, E',\n'
				) FROM information_schema.columns c1 WHERE c1.table_schema = '' || tablename || '' AND c1.table_name = '' || tablename || '' AND c1.column_name
		NOT IN (SELECT c2.column_name FROM information_schema.columns c2 WHERE c2.table_schema = 'log' AND c2.table_name = '' || tablename || '')
		INTO addColumnsString;

		IF NOT(addColumnsString = '') THEN
			addColumnsString := 'ALTER TABLE log."' || tableName || '" ' || addColumnsString || ';';
			EXECUTE addColumnsString;
		end if;
	end if;

	triggerString := 'CREATE OR REPLACE FUNCTION ' || tableSchema || '."trigger.log.' || tableName || '"()
    RETURNS trigger
    LANGUAGE ''plpgsql''
    COST 100
    VOLATILE NOT LEAKPROOF
	AS $BODY$
	BEGIN
		if (current_setting(''ctx.' || tableSchema || '.' || tableName || '.LogTrigger'', ''t'') = ''ON'') then
			return null;
		end if;
		set ctx.' || tableSchema || '.' || tableName || '.LogTrigger = ''ON'';
		if  (TG_OP = ''INSERT'') then
			update ' || tableSchema || '."' || tableName || '"
				set username = admin."ctxUserName"()
			  	, stamp = now()
				where "' || primaryKeyName || '" = new."' || primaryKeyName || '";
    	end if;
    	if  (TG_OP = ''UPDATE'') then
			update ' || tableSchema || '."' || tableName || '" set username = admin."ctxUserName"(), stamp = now() where "' || primaryKeyName || '" = old."' || primaryKeyName || '" ;
	 		insert into log."' || tableName || '"(' || columnsString || ', "username", "stamp")
				values(' || valuesString || ', old."username", old."stamp");
			end if;
      if  (TG_OP = ''DELETE'') then
			insert into log."' || tableName || '"(' || columnsString || ', "username", "stamp")
				values(' || valuesString || ', old."username", old."stamp");
			insert into log."' || tableName || '"(' || columnsString || ', "username", "stamp")
				 values(' || valuesString || ', admin."ctxUserName"(), now());
			end if;
			set ctx.' || tableSchema || '.' || tableName || '.LogTrigger = ''OFF'';
  		return null;
	END;

	$BODY$;';
/*ALTER FUNCTION ' || tableSchema || '."' || tableSchema || '.' || tableName || '.LogTrigger"()
    	OWNER TO postgres;*/
	logTableFunctionString := 'create trigger "trigger.set.' || tableName || '"
	after insert or update or delete
	on ' || tableSchema || '."' || tableName || '"
	for each row
	execute procedure ' || tableSchema || '."trigger.log.' || tableName || '"();';

	dropTriggerString := 'DROP TRIGGER IF EXISTS "trigger.set.' || tableName || '" ON ' || tableSchema || '."' || tableName || '";';

	EXECUTE  dropTriggerString;
	EXECUTE triggerString;
	EXECUTE logTableFunctionString;
END
$$;

alter function "generateLogTable"(text, text) owner to postgres;

