create function "trigger.log.userRol"() returns trigger
    language plpgsql
as
$$
BEGIN
		if (current_setting('ctx.admin.userRol.LogTrigger', 't') = 'ON') then
			return null;
		end if;
		set ctx.admin.userRol.LogTrigger = 'ON';
		if  (TG_OP = 'INSERT') then
			update admin."userRol"
				set username = admin."ctxUserName"()
			  	, stamp = now()
				where id = new.id;
    	end if;
    	if  (TG_OP = 'UPDATE') then
			update admin."userRol" set username = admin."ctxUserName"(), stamp = now() where id = old.id ;
	 		insert into log."userRol"(    "id" ,    "idRol" , "username", "stamp")
				values(    old."id" ,    old."idRol" , old."username", old."stamp");
			end if;
      if  (TG_OP = 'DELETE') then
			insert into log."userRol"(    "id" ,    "idRol" , "username", "stamp")
				values(    old."id" ,    old."idRol" , old."username", old."stamp");
			insert into log."userRol"(    "id" ,    "idRol" , "username", "stamp")
				 values(    old."id" ,    old."idRol" , admin."ctxUserName"(), now());
			end if;
			set ctx.admin.userRol.LogTrigger = 'OFF';
  		return null;
	END;


$$;

alter function "trigger.log.userRol"() owner to postgres;

