create function gis_create_route_linestring(route_id integer) returns integer
    language sql
as
$$
update  public.routes 
set geom = (public.st_makeline( array(select geom from public."routeSegments" where "idRoute" = $1 order by seq asc))),
"length" = (select sum(cost) from public."routeSegments" where "idRoute" = $1)							  
where "id" = $1;

select 1;

$$;

alter function gis_create_route_linestring(integer) owner to postgres;

