create function gis_restrict_ways_segments(restriction_id integer) returns integer
    language plpgsql
as
$$
declare
 way_restrict record;
 insert_res integer;
begin
 	if restriction_id  is null then
 		return -1;
	end if;
	
 	execute 'select * from public."restrictWays" where id = $1 limit 1' using restriction_id into way_restrict;
 
 	if way_restrict."geomType" is null then
 		return -1;
	end if;
 	if way_restrict."geomType" = 'polygon' then
		if way_restrict.zone is null then
			return -1;
		end if;
		--
		execute 'delete from  public."restrictWaysSegment" where "restrictWayId" = $1' using  restriction_id;
	
		--
		execute 'with "resSegm" as (select * from ruteosm.ways where st_intersects($1, the_geom))
 			insert into public."restrictWaysSegment"("restrictWayId", "segmentId", "waySegment")
 			(select ($2) as "RestrictWayId", gid as "segmentId", "the_geom" as "waySegment" from "resSegm" ) returning 3'
  		using way_restrict.zone, way_restrict.id into insert_res;
		return 2;
	end if;
	
	--
	if way_restrict."geomType" = 'point' then
		if way_restrict.location is null then
			return -1;
		end if;
		--
		execute 'delete from  public."restrictWaysSegment" where "restrictWayId" = $1' using  restriction_id;
		--
		execute 'with "resSegm" as( select * from  ruteosm.ways
       	      where st_dwithin( $1, the_geom, $3)
				 order by st_distance($1, the_geom) asc limit 1)
			insert into public."restrictWaysSegment"("restrictWayId", "segmentId", "waySegment")
 			(select ($2) as "RestrictWayId", gid as "segmentId", "the_geom" as "waySegment" from "resSegm" ) returning 3'
		using way_restrict.location, way_restrict.id, 0.5
		into insert_res;
		return 3;
	end if;
	if way_restrict."geomType" = 'stringLine' then
 		return 4;
	end if;
	
 
return 1;
end

$$;

alter function gis_restrict_ways_segments(integer) owner to postgres;

