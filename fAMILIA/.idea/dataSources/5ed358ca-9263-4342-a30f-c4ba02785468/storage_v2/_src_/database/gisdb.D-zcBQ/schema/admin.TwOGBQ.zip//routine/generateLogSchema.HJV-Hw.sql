create function "generateLogSchema"(tableschema text) returns void
    language plpgsql
as
$$
DECLARE
    tables CURSOR FOR
      SELECT * FROM information_schema.tables
      WHERE table_schema = '' || tableschema || '' and table_type = 'BASE TABLE';
BEGIN
	  FOR table_record IN tables LOOP
      PERFORM admin."generateLogTable"(table_record.table_name,'' || tableschema || '');
    END LOOP;
END
$$;

alter function "generateLogSchema"(text) owner to postgres;

