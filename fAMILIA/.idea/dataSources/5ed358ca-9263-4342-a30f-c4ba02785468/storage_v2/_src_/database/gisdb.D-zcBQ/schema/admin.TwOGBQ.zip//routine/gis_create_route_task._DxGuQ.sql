create function gis_create_route_task(name text) returns integer
    language sql
as
$$
LOCK TABLE public."taskTracker" IN SHARE MODE;
insert into public."taskTracker"("type", "name", "status", "time")
	(select 'do_rute_dispozitive_zi' as "type", $1 as "name",'rute_task_creat' as "status" ,  clock_timestamp() as "time"
	where not exists(
		select * from public."taskTracker" where "type" = 'do_rute_dispozitive_zi' and "name" =  $1
	)) returning id;

$$;

alter function gis_create_route_task(text) owner to postgres;

