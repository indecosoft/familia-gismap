create function gis_adhoc_change_seq_tsp_pg(route_id integer) returns void
    language plpgsql
as
$fun$
declare
rr_part record;
rr_res record;
rr_point record;
rr_route record;
cost_tmp double precision;
tree_query text;
id_point integer;
id_judete_str text;
start_seq integer;
end_seq integer;
begin

drop table if exists tb_route_parts;
create temp table tb_route_parts (
	id integer,
	seq_a integer,
	edge_a integer,
	fraction_a double precision,
	seq_b integer,
	edge_b integer,
	fraction_b double precision,
	cost double precision
);
--
insert into tb_route_parts(id, seq_a, edge_a, fraction_a, seq_b, edge_b, fraction_b)
	select ROW_NUMBER () OVER(order by rp1.seq, rp2.seq) AS id, rp1.seq, rp1.edge, rp1.fraction, rp2.seq, rp2.edge, rp2.fraction from public."routePoints" as rp1 
cross join public."routePoints" as rp2 
where rp1."idRoute" = route_id and rp2."idRoute" = route_id and rp1.seq <> rp2.seq
order by rp1.seq, rp2.seq;
--tree_query = 'select id, source, target, cost, reverse_cost from (select gid::int4 as id,  source::int4, target::int4, cost::float8, reverse_cost::float8 from public."strazi_judete_full") as w'::text,
execute  'select * from public."routes" where "id" = $1'into rr_route using route_id;
--
tree_query := admin.gis_routing_ways_query_pg(rr_route."idsJudeteRestrict",rr_route."tipRestrictWays");

--
CREATE TEMP TABLE tb_route_points ON COMMIT DROP AS
select * from public."routePoints"
where "idRoute" = route_id
order by "seq";
--
for rr_part in select * from tb_route_parts loop
--
select sum(cost)
from public.pgr_trsp(tree_query,
		rr_part.edge_a, rr_part.fraction_a, rr_part.edge_b, rr_part.fraction_b, false, true, null) into cost_tmp;
	--raise notice' cost % ', cost_tmp;
	rr_part.cost := cost_tmp;
	update tb_route_parts set cost = cost_tmp where id = rr_part.id;
	--
	--raise notice 'valori % - % - % - %', rr_part.id, rr_part.seq_a, rr_part.seq_b, rr_part.cost;
end loop;

select sum(cost) from tb_route_parts into cost_tmp;
raise notice 'total cost % ', cost_tmp;

select min(seq) from tb_route_points into start_seq;
select max(seq) from tb_route_points into end_seq;
--
CREATE TEMP TABLE tb_point_order ON COMMIT DROP AS
select * from pgr_tsp(matrix_row_sql := $$ select seq_a as start_vid, seq_b as end_vid, COALESCE(cost, 0.0) as agg_cost from tb_route_parts $$,
			start_id := start_seq,
			end_id := end_seq
		);

-- for rr_res in select * from tb_point_order loop
-- 	select id from tb_route_points where seq = rr_res.node into id_point;
-- 	raise notice 'res % - % - % - % - %', rr_res.seq, rr_res.node, rr_res.cost, rr_res.agg_cost, id_point;
-- 	if id_point is not null then
-- 		update public."routePoints" set seq = rr_seq
-- 	end if;
-- end loop;

for rr_point in select * from tb_route_points loop
 	select * from tb_point_order where node = rr_point.seq into rr_res;
	--
 	--raise notice 'res % - % - % - % - %', rr_res.seq, rr_res.node, rr_res.cost, rr_res.agg_cost, rr_point.seq;
	--
 	update public."routePoints" set seq = rr_res.seq where "id" = rr_point.id and "idRoute" = route_id;
end loop;

end;
$fun$;

alter function gis_adhoc_change_seq_tsp_pg(integer) owner to postgres;

