create view v_roluri_resurse
            ("idRol", "numeRol", "idClient", "idResursa", "numeResursa", type, descriere, access, "idResursaRol") as
SELECT rr."idRol",
       ro.nume AS "numeRol",
       ro."idClient",
       rr."idResursa",
       re.nume AS "numeResursa",
       re.type,
       re.descriere,
       rr.access,
       rr.id   AS "idResursaRol"
FROM admin."resursaRol" rr
         JOIN admin.resursa re ON rr."idResursa" = re.id
         JOIN admin.rol ro ON rr."idRol" = ro.id
ORDER BY ro."idClient", ro.id;

alter table v_roluri_resurse
    owner to postgres;

