create function gis_adhoc_change_seq_tsp(route_id integer) returns void
    language sql
as
$$
with neworder as (SELECT seq, id1, id2, round(cost::numeric, 1) AS cost
   FROM pgr_tsp('select id, lat as x, long as y from public."routePoints" where "idRoute" = '||route_id||'',
				(select min(id) from  public."routePoints" where "idRoute" = route_id)
				))
				--select * from neworder;
				update public."routePoints" 
				set seq = (select n.seq from neworder as n where id2 = "id" limit 1) + 1
				where "idRoute" = route_id;

$$;

alter function gis_adhoc_change_seq_tsp(integer) owner to postgres;

