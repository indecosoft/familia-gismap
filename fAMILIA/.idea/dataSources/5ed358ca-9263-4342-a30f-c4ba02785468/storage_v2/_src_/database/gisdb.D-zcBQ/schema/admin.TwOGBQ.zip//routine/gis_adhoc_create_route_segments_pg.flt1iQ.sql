create function gis_adhoc_create_route_segments_pg(route_id integer) returns integer
    language plpgsql
as
$$
declare
 var_status text;
 var_route record;
 var_directed boolean;
begin
	--lock task and coresponding routes
	execute  'select * from public."routes" where "id" = $1 for update NOWAIT;'into var_route using route_id;
	execute 'select * from public."routePoints" where "idRoute" = $1 for update NOWAIT;' using route_id;
	var_directed := false;
	if var_route."routingType" is not null and var_route."routingType" = 'car' then
		var_directed := true;
	end if;
	--
	execute 'select admin.gis_create_route_segments_intablesql_restrict($1, $2, $3, $4);' using route_id, var_route."idsJudeteRestrict", var_route."tipRestrictWays", var_directed;

	--
	execute 'update public.routes set status = $2, time = clock_timestamp() 
	where "id" = $1;' using route_id, 'rute_end_segmente_generate' ;
	--
	return 1;
end;

$$;

alter function gis_adhoc_create_route_segments_pg(integer) owner to postgres;

