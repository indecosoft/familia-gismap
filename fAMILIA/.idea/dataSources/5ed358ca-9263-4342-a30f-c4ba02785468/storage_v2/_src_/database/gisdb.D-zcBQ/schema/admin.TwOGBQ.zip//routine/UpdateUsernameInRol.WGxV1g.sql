create function "UpdateUsernameInRol"(newid integer) returns void
    language plpgsql
as
$$
BEGIN
		UPDATE admin.rol SET "username" = admin."getUserName"()
			WHERE id = newid;
    END;
$$;

alter function "UpdateUsernameInRol"(integer) owner to postgres;

