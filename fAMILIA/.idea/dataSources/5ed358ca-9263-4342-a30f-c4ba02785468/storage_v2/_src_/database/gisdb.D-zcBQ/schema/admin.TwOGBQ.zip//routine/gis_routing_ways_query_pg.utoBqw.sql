create function gis_routing_ways_query_pg(ids_judete integer[], restrict_type text) returns text
    language plpgsql
as
$$
DECLARE
 id_judete_str text;
 ways_query text;
BEGIN
--
case when ids_judete is not null then
	id_judete_str := array_to_string(ids_judete,',','-1');
	--RAISE NOTICE ' array id string  %', id_judete_str;
else
	id_judete_str := null;
end case;
----
case when ids_judete is not null and array_length(ids_judete, 1) >= 0 and restrict_type is not null then
-- restrict by type and ids judete
	ways_query := 'select w.id, w.source, w.target, (w.cost * w.coef) as cost, (w.reverse_cost * w.coef) as  reverse_cost
					from (select gid::int4 as id,  source::int4, target::int4, cost::float8, reverse_cost::float8 ,
		  					(select admin.gis_restricted_segment_coeficient(gid::integer, '||quote_literal(restrict_type)||'))::float8 as coef
						from public."strazi_judete_full" where array['|| id_judete_str ||'] && id_judet) as w';

when ids_judete is not null and array_length(ids_judete, 1) >= 0 and restrict_type is null then
-- restrict by ids judete
	ways_query := 'select id, source, target, cost, reverse_cost 
					from (select gid::int4 as id,  source::int4, target::int4, cost::float8, reverse_cost::float8 
						from public."strazi_judete_full" where  array['|| id_judete_str ||'] && id_judet) as w';
else					
	--'select gid as id,  cast(ways.source as int4) as source, target::int4, cost::float8, reverse_cost from ways',
	--'select id, source, target, cost, reverse_cost from (select gid::int4 as id,  source::int4, target::int4, cost::float8, reverse_cost::float8 from ruteosm.ways) as w'
	ways_query := 'select id, source, target, cost, reverse_cost from (select gid::int4 as id,  source::int4, target::int4, cost::float8, reverse_cost::float8 from public."strazi_judete_full") as w';
					
end case;
--
return ways_query;
--
END;
$$;

alter function gis_routing_ways_query_pg(integer[], text) owner to postgres;

