create function "trigger.log.deviceConfig"() returns trigger
    language plpgsql
as
$$
BEGIN
		if (current_setting('ctx.admin.deviceConfig.LogTrigger', 't') = 'ON') then
			return null;
		end if;
		set ctx.admin.deviceConfig.LogTrigger = 'ON';
		if  (TG_OP = 'INSERT') then
			update admin."deviceConfig"
				set username = admin."ctxUserName"()
			  	, stamp = now()
				where id = new.id;
    	end if;
    	if  (TG_OP = 'UPDATE') then
			update admin."deviceConfig" set username = admin."ctxUserName"(), stamp = now() where id = old.id ;
	 		insert into log."deviceConfig"(    "id" ,    "idClient" ,    "idPersoana" ,    "dataStart" ,    "dataStop" ,    "imei" ,    "geolocationSafeArea" ,    "geolocationSafeDistance" ,    "stepCounter" ,    "bloodPressureSystolic" ,    "bloodPressureDiastolic" ,    "bloodPressurePulseRate" ,    "bloodGlucose" ,    "socializationActive" ,    "panicPhoneNumbers" ,    "medication" ,    "datetime" ,    "dataSendInterval" ,    "oxygenSaturation" ,    "locationSendInterval" , "username", "stamp")
				values(    old."id" ,    old."idClient" ,    old."idPersoana" ,    old."dataStart" ,    old."dataStop" ,    old."imei" ,    old."geolocationSafeArea" ,    old."geolocationSafeDistance" ,    old."stepCounter" ,    old."bloodPressureSystolic" ,    old."bloodPressureDiastolic" ,    old."bloodPressurePulseRate" ,    old."bloodGlucose" ,    old."socializationActive" ,    old."panicPhoneNumbers" ,    old."medication" ,    old."datetime" ,    old."dataSendInterval" ,    old."oxygenSaturation" ,    old."locationSendInterval" , old."username", old."stamp");
			end if;
      if  (TG_OP = 'DELETE') then
			insert into log."deviceConfig"(    "id" ,    "idClient" ,    "idPersoana" ,    "dataStart" ,    "dataStop" ,    "imei" ,    "geolocationSafeArea" ,    "geolocationSafeDistance" ,    "stepCounter" ,    "bloodPressureSystolic" ,    "bloodPressureDiastolic" ,    "bloodPressurePulseRate" ,    "bloodGlucose" ,    "socializationActive" ,    "panicPhoneNumbers" ,    "medication" ,    "datetime" ,    "dataSendInterval" ,    "oxygenSaturation" ,    "locationSendInterval" , "username", "stamp")
				values(    old."id" ,    old."idClient" ,    old."idPersoana" ,    old."dataStart" ,    old."dataStop" ,    old."imei" ,    old."geolocationSafeArea" ,    old."geolocationSafeDistance" ,    old."stepCounter" ,    old."bloodPressureSystolic" ,    old."bloodPressureDiastolic" ,    old."bloodPressurePulseRate" ,    old."bloodGlucose" ,    old."socializationActive" ,    old."panicPhoneNumbers" ,    old."medication" ,    old."datetime" ,    old."dataSendInterval" ,    old."oxygenSaturation" ,    old."locationSendInterval" , old."username", old."stamp");
			insert into log."deviceConfig"(    "id" ,    "idClient" ,    "idPersoana" ,    "dataStart" ,    "dataStop" ,    "imei" ,    "geolocationSafeArea" ,    "geolocationSafeDistance" ,    "stepCounter" ,    "bloodPressureSystolic" ,    "bloodPressureDiastolic" ,    "bloodPressurePulseRate" ,    "bloodGlucose" ,    "socializationActive" ,    "panicPhoneNumbers" ,    "medication" ,    "datetime" ,    "dataSendInterval" ,    "oxygenSaturation" ,    "locationSendInterval" , "username", "stamp")
				 values(    old."id" ,    old."idClient" ,    old."idPersoana" ,    old."dataStart" ,    old."dataStop" ,    old."imei" ,    old."geolocationSafeArea" ,    old."geolocationSafeDistance" ,    old."stepCounter" ,    old."bloodPressureSystolic" ,    old."bloodPressureDiastolic" ,    old."bloodPressurePulseRate" ,    old."bloodGlucose" ,    old."socializationActive" ,    old."panicPhoneNumbers" ,    old."medication" ,    old."datetime" ,    old."dataSendInterval" ,    old."oxygenSaturation" ,    old."locationSendInterval" , admin."ctxUserName"(), now());
			end if;
			set ctx.admin.deviceConfig.LogTrigger = 'OFF';
  		return null;
	END;


$$;

alter function "trigger.log.deviceConfig"() owner to postgres;

