create function gis_create_day_routes_and_points(date text, task_id integer) returns integer
    language sql
as
$$
--delete device routes for day
delete from public.routes where "type" = 'dispozitiv_pe_zi' and "dateiso" = $1;

--create route descriptions
with dayimei as( SELECT distinct dm."imei", dm."idClient"
	FROM public."deviceMeasurement" as dm
	where dm."dateTimeISO"::date = date($1) )
	--select * from dayimei
	insert into public.routes("name", "imei", "dateiso", "type", "idClient" ,"idTask") 
	(select 'ruta dispozitiv pe zi', "imei", $1 as "dateiso", 'dispozitiv_pe_zi' as "type", "idClient" , $2 as "idTask" from dayimei );
	
--create route points	
insert into public."routePoints"("idRoute", "idSource", "location", "seq", "idClient")  
  (select dayroutes.id as "idRoute", daymeas."id" as "idSource", daymeas."geolocation" as "location", daymeas."id" as "seq", daymeas."idClient" 
  from (SELECT * FROM  public.routes where "idTask" = $2) as dayroutes
  join (select * from public."deviceMeasurement" where  "dateTimeISO"::date = date($1)) as daymeas
  on dayroutes.imei = daymeas.imei
  order by dayroutes.imei asc, daymeas."dateTimeISO" asc);
  
--update task count state
update public."taskTracker" set "routes" = (select count(*) from public."routes" where "idTask" = $2),
	"points" = (select count(*) from public."routePoints" where "idRoute" in 
    (select id from public.routes where "idTask" = $2))
	where "id" = $2;
--update routes status
update public.routes set status = 'rute_end_puncte_asociate', time = clock_timestamp() 
where "idTask" = $2;

--create points relations to route
--select public.gis_create_route_relation_for_point("id", 0.1) from public."routePoints" where
-- "idRoute" in (SELECT id FROM  public.routes where "type" = 'dispozitiv_pe_zi' and "dateiso" = $1);

--create route segments
--select public.gis_create_route_segments_intablesql("id") 
--FROM  public.routes where "type" = 'dispozitiv_pe_zi' and "dateiso" = $1;
 
 --create route linestring overview
-- select public.gis_create_route_linestring("id")
-- FROM  public.routes where "type" = 'dispozitiv_pe_zi' and "dateiso" = $1;
 
select 1;

$$;

alter function gis_create_day_routes_and_points(text, integer) owner to postgres;

