create function gis_restricted_segment_coeficient(segment_id integer, restrict_type character varying) returns double precision
    language plpgsql
as
$$
declare
	return_coef double precision;
begin
return_coef := 1.0;
if segment_id is null or restrict_type is null then
	return 1.0;
end if;
case restrict_type
when 'trafic_greu'then
	select max(coeficient)
	from public."v_restrictWaysWithSegments" 
	where "segmentId" = segment_id and "restrictType" = restrict_type
	into return_coef;
	return coalesce(return_coef, 1.0);
when 'defineste' then
	return 1.5;
else
	return 1.0;
end case;
end
$$;

alter function gis_restricted_segment_coeficient(integer, varchar) owner to postgres;

