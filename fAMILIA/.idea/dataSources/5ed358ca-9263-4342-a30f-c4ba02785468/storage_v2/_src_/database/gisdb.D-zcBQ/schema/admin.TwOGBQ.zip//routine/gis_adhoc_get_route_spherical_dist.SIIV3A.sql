create function gis_adhoc_get_route_spherical_dist(route_id integer)
    returns TABLE("idRoute" integer, "subrouteId" integer, dist double precision, "distAgg" double precision, "sfDist" double precision, "sfDistAgg" double precision)
    language sql
as
$$
with route_seg as (select * from public."routeSegments" as r
	where r."idRoute" = route_id order by seq),
route_part as(
	select s."idRoute", s."subrouteId", sum(cost) as dist, sum(st_length(s.geom::geometry,false)) sf_dist 
	from route_seg as s
	group by s."idRoute", s."subrouteId"),
route_res as(
select p."idRoute",p."subrouteId" as "subrouteId_o",p.dist as "dist_o",
	sum(p.dist) over(order by p."subrouteId" rows between unbounded preceding and current row ) as agg_dist_o,
	p.sf_dist as sf_dist_o, 
	sum(p.sf_dist) over(order by p."subrouteId" rows between unbounded preceding and current row ) as agg_sf_dist_o
	from route_part as p)
select * from route_res;										   ;

$$;

alter function gis_adhoc_get_route_spherical_dist(integer) owner to postgres;

