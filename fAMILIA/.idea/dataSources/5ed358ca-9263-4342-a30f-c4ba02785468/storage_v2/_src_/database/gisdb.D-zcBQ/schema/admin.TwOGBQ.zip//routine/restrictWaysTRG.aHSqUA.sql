create function "restrictWaysTRG"() returns trigger
    language plpgsql
as
$$
declare
 res record;
begin
 select admin.gis_restrict_ways_segments(new.id) into res;
 return null;
end;
$$;

alter function "restrictWaysTRG"() owner to postgres;

