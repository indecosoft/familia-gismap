create function gis_delete_route_task_pg(task_id integer) returns integer
    language plpgsql
as
$$
declare
 var_status text;
begin
--lock task and coresponding routes
execute 'select * from public."taskTracker" where "id" = $1 for update NOWAIT;' using task_id;
execute  'select * from public."routes" where "idTask" = $1 for update NOWAIT;' using task_id;

execute 'delete from public."routes" where "idTask" = $1;' using task_id;
execute 'delete from public."taskTracker" where "id" = $1;' using task_id;

return 1;

end;

$$;

alter function gis_delete_route_task_pg(integer) owner to postgres;

