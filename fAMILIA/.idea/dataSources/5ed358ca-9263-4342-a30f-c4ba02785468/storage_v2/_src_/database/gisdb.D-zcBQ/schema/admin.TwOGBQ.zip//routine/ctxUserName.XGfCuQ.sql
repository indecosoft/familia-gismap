create function "ctxUserName"() returns character varying
    language sql
as
$$
SELECT coalesce(current_setting('ctx.userName', 't'), CURRENT_USER);

$$;

alter function "ctxUserName"() owner to postgres;

