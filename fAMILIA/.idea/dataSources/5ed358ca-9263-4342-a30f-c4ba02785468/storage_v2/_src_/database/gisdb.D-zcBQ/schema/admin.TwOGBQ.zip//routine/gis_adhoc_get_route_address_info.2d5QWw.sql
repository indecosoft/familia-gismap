create function gis_adhoc_get_route_address_info(route_id integer) returns json
    language plpgsql
as
$$
declare
	ret_info json;
	points_info json;
	route_rec record;
begin
--route info
select * from public.routes where id = route_id into route_rec;

--points info
if route_rec."locationType" is not null and route_rec."locationType" = 'uuid_address' then
--
 select array_to_json(array_agg(row_to_json(t))) from
(select 
	--rp."idRoute",
 	rp.id,
 	rp.seq as out_seq,
	row_number() over(order by rp.id asc) as in_seq,
	rp."strSource" as uuid,
	lo."numarPostal", lo."strada", lo."localitate", lo."judet",
	coalesce(pa."cost", 0)::integer as dist,
	sum(coalesce(pa."cost", 0)) over(order by rp.seq)::integer as dist_agg
from public."routePoints" as rp
left outer join "locatieAdresa" as lo on rp."strSource" = lo."uuidNumarPostal"
left outer join "routeParts" as pa on pa."idRoute" = rp."idRoute" and pa."target" = rp.seq
where rp."idRoute" = route_id
order by rp.seq) as t
		into points_info;
--
else 
--
		select array_to_json(array_agg(row_to_json(t))) from
(select 
	--rp."idRoute",
 	rp.id,
 	rp.seq as out_seq,
	row_number() over(order by rp.id asc) as in_seq,
	coalesce(pa."cost", 0)::integer as dist,
	sum(coalesce(pa."cost", 0)) over(order by rp.seq)::integer as dist_agg
from public."routePoints" as rp
left outer join "routeParts" as pa on pa."idRoute" = rp."idRoute" and pa."target" = rp.seq
where rp."idRoute" = route_id
order by rp.seq) as t
		into points_info;
--
end if;
		
return json_build_object ('id', route_id, 'length', route_rec.length, 'points', points_info);
end;
$$;

alter function gis_adhoc_get_route_address_info(integer) owner to postgres;

