create function gis_create_route_relation_for_point_restricted(meas_id integer, tol double precision, judet_id integer) returns integer
    cost 5
    language plpgsql
as
$$
declare
	--tbl_measurement text;
	--tbl_poition_to_route text;
	rr_meas record;
	point_meas geometry;
    rr_route record;
	segment_id integer;
    segment_pct float;
	segment_vertex integer;
	segment_point geometry(Point, 4326);
    debuglevel text;

begin
	-- select the row from the device table
	execute 'select * from "routePoints" where id = '|| meas_id || ' limit 1' into rr_meas;
	
   if rr_meas is null then
   -- return a failure if no measure was found
		return -1;
   else
   	point_meas := ST_SetSRID(rr_meas.location,4326);
    -- find the closest edge within tol distance
--     execute 'select * from ruteosm.ways'||
--             ' where st_dwithin(''' || point_meas::text ||
--             '''::geometry, the_geom, ' || tol || ') order by st_distance(''' || point_meas::text ||
--             '''::geometry, the_geom) asc limit 1' into rr_route;

	execute ' select * from  public."strazi_judete_full"'
            || ' where $3 = any(id_judet) and st_dwithin( $1, the_geom, $2)'
			|| ' order by st_distance($1, the_geom) asc limit 1' 
	using point_meas, tol, judet_id
	into rr_route;

    if rr_route.the_geom is null then
	-- return a failure to find an edge within tol distance
        return -2;
	else
        -- deal with MULTILINESTRINGS
        if geometrytype(rr_route.the_geom)='MULTILINESTRING' THEN
            rr_route.the_geom := ST_GeometryN(rr_route.the_geom, 1);
        end if;

        -- project the point onto the linestring
        execute 'show client_min_messages' into debuglevel;
        SET client_min_messages='ERROR';
		segment_id := rr_route.gid;
        segment_pct := st_line_locate_point(rr_route.the_geom, point_meas);
        execute 'set client_min_messages  to '|| debuglevel;
		-- 
		if segment_pct < 0.5 then
			segment_vertex := rr_route.source;
		else
			segment_vertex := rr_route.target;
		end if;
		segment_point := st_line_interpolate_point(rr_route.the_geom, segment_pct);
		
		execute  'update public."routePoints" set "edge" = $2, "fraction" = $3, "vertex" = $4, "geom" = ST_SetSRID( $5 ::geometry,4326), "long" = $6, "lat"= $7 where "id" = $1;'
		USING meas_id, segment_id, segment_pct, segment_vertex, ST_AsText(segment_point), st_x(segment_point),  st_y(segment_point);
		
		
		--execute 'insert into public."deviceRoutePosition"("idMeas", edge, fraction, vertex, geom, long, lat) values($1, $2, $3, $4, ST_SetSRID( $5 ::geometry,4326) , $6, $7);'
		--USING meas_id, segment_id, segment_pct, segment_vertex, ST_AsText(segment_point), st_x(segment_point),  st_y(segment_point);
		
		return segment_id;
        
		end if;
	end if;
end;

$$;

alter function gis_create_route_relation_for_point_restricted(integer, double precision, integer) owner to postgres;

