create function "trigger.log.user"() returns trigger
    language plpgsql
as
$$
BEGIN
		if (current_setting('ctx.admin.user.LogTrigger', 't') = 'ON') then
			return null;
		end if;
		set ctx.admin."user".LogTrigger = 'ON';
		if  (TG_OP = 'INSERT') then
			update admin."user"
				set username = admin."ctxUserName"()
			  	, stamp = now()
				where id = new.id;
    	end if;
    	if  (TG_OP = 'UPDATE') then
			update admin."user" set username = admin."ctxUserName"(), stamp = now() where id = old.id ;
	 		insert into log."user"(    "id" ,    "idClient" ,    "nume" ,    "password" ,    "email" ,    "phone" ,    "emailConfirmed" ,    "disabled" , "username", "stamp")
				values(    old."id" ,    old."idClient" ,    old."nume" ,    old."password" ,    old."email" ,    old."phone" ,    old."emailConfirmed" ,    old."disabled" , old."username", old."stamp");
			end if;
      if  (TG_OP = 'DELETE') then
			insert into log."user"(    "id" ,    "idClient" ,    "nume" ,    "password" ,    "email" ,    "phone" ,    "emailConfirmed" ,    "disabled" , "username", "stamp")
				values(    old."id" ,    old."idClient" ,    old."nume" ,    old."password" ,    old."email" ,    old."phone" ,    old."emailConfirmed" ,    old."disabled" , old."username", old."stamp");
			insert into log."user"(    "id" ,    "idClient" ,    "nume" ,    "password" ,    "email" ,    "phone" ,    "emailConfirmed" ,    "disabled" , "username", "stamp")
				 values(    old."id" ,    old."idClient" ,    old."nume" ,    old."password" ,    old."email" ,    old."phone" ,    old."emailConfirmed" ,    old."disabled" , admin."ctxUserName"(), now());
			end if;
			set ctx.admin."user".LogTrigger = 'OFF';
  		return null;
	END;


$$;

alter function "trigger.log.user"() owner to postgres;

