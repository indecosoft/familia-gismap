create function gis_admin_get_user_resources_with_options(user_id integer, client_id integer)
    returns TABLE(id integer, nume character varying, descriere character varying, type character varying, "accessPermis" boolean, "defaultAccess" boolean, options json[])
    language sql
as
$$
with usrol as (select  ur."idRol", ur."indexRol"
         from admin."userRol" ur
         join admin."user" as u on u."username" = ur."username"
         where u."id" = $1 and u."idClient" = $2),
--
usres as (select rr.id, rr."idRol", rr."idResursa", rr."access", ur."indexRol"
         from usrol ur
         join admin."resursaRol" rr on ur."idRol" = rr."idRol"
         where rr."access" = true),
opt_res as ( select * from admin."optiuneResursa" where "idResursa" in (select "idResursa" from usres)
			order by "idResursa" asc, "id" asc),		
-- optiunile pentru resurse corespunzatoare rolurilor		
opt_rol_res as(	select row_number()over(order by oprr."idOptiuneResursa") as idtr, ur."indexRol"
			,oprr."idRol", oprr."idOptiuneResursa",opr."idResursa", opr."nume", oprr."overrideDefaults", oprr.access
			,oprr."idItem", oprr."descriere", oprr."customAccess"
			--,opr."idItem" as "d_idItem", opr."descriere" as "d_descriere", opr."customAccess" as "d_customAccess"
			from admin."optiuneResursaRol" as oprr
			join admin."optiuneResursa" as opr on oprr."idOptiuneResursa" = opr."id"
			join usrol as ur on ur."idRol"= oprr."idRol"
 			where --oprr."access" = true and 
				oprr."idRol" in (select  usres."idRol"  from usres where usres."idResursa" = opr."idResursa" )
			order by oprr."idOptiuneResursa"),
-- ordoneaza dupa overrideAccess si in ordinea importantei rolului(index rol)			
opt_rank as (select  *
			, rank() over(partition by "idResursa", "idOptiuneResursa" order by "access" desc, "overrideDefaults" desc, "indexRol" asc) as rank
			, bool_and("access") over(partition by "idResursa", "idOptiuneResursa") as "keepDefaultAccess"
			from opt_rol_res order by  "idResursa" asc, "idOptiuneResursa" asc,"access" desc, "overrideDefaults" desc),
-- filtreaza cea mai semnificativa optiune
opt_filtr  as (select * from opt_rank where rank = 1),
res_full_opt as ( select  o.id as o_id, o."idResursa" as "o_idResursa", o.nume as o_nume, o.descriere as o_descriere
				, o."defaultAccess" as "o_defaultAccess", o."customAccess" as "o_customAccess", o."idItem" as "o_idItem"
				, f.*
			from opt_res as o
			left outer join opt_filtr as f on o.id = f."idOptiuneResursa" and o."idResursa" = f."idResursa"
			order by o."idResursa" asc, o."id" asc),
res_build_opt as (
		select 
		(case when "o_defaultAccess" = true and "keepDefaultAccess" = false  then
		 	false
		 when ("o_defaultAccess" = true and "access" = true) 
		 	or("o_defaultAccess" = false and "access" = true)
			  or("o_defaultAccess" = true and ("access" is null)) then
		 	true
		 else 
		 	false
		 end) as c_access
		,(case when "o_defaultAccess" = true and "keepDefaultAccess" = false  then
		 	"o_idItem"
		 when (("o_defaultAccess" = false and "access" = true) 
		 	or("o_defaultAccess" = true and "access" = true)) and "overrideDefaults" = true then
		 	"idItem"
		 else 
		 	"o_idItem"
		 end) as c_idItem
		,(case when "o_defaultAccess" = true and "keepDefaultAccess" = false  then
		 	"o_descriere"
		 when (("o_defaultAccess" = false and "access" = true) 
		 	or("o_defaultAccess" = true and "access" = true)) and "overrideDefaults" = true then
		 	"descriere"
		 else 
		 	"o_descriere"
		 end) as c_descriere
		,(case when "o_defaultAccess" = true and "keepDefaultAccess" = false  then
		 	"o_customAccess"
		 when (("o_defaultAccess" = false and "access" = true) 
		 	or("o_defaultAccess" = true and "access" = true)) and "overrideDefaults" = true then
		 	"customAccess"
		 else 
		 	"o_customAccess"
		 end) as "c_customAccess"
		,* from res_full_opt
),
res_rename_opt as (
	select "o_id" as "id", "o_nume" as "nume",  c_access as "access", "c_iditem" as "idItem",
	"c_descriere" as "descriere", "c_customAccess" as "customAccess",
	"o_defaultAccess" as "defaultAccess", "o_idResursa" as "idResursa"
--,*
from res_build_opt where c_access = true
)
--select * from usres order by "idResursa" asc, "idRol" asc;
--select * from opt_res
--select * from opt_rol_res
--select * from opt_rank
--select * from opt_filtr
--select * from res_build_opt
--select * from res_rename_opt
select res."id", res."nume", res."descriere", res."type", true as "accessPermis", res."defaultAccess"
, array( select row_to_json("res_rename_opt")
		from res_rename_opt where "idResursa" = res."id") as options
	from admin.resursa as res where res.id in (select "idResursa" from usres)
	 or (res.type = 'object' and res."defaultAccess" = true)
	order by res."id" asc;

$$;

alter function gis_admin_get_user_resources_with_options(integer, integer) owner to postgres;

