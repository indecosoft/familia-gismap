create function admin_delete_client(cient_id integer) returns json
    language plpgsql
as
$$
begin
end;
$$;

alter function admin_delete_client(integer) owner to postgres;

