create function "actualizareOptiuneResursaRol"("idRolP" integer, "idOptiuneResursaP" integer, "accessP" boolean, "customAccessP" character varying, "idItemP" integer, "descriereP" character varying, "overrideDefaultsP" boolean) returns void
    language plpgsql
as
$$
BEGIN
	IF EXISTS(SELECT 1 FROM admin."optiuneResursaRol" WHERE "idRol" = $1 AND "idOptiuneResursa" = $2) THEN
		IF EXISTS(SELECT 1 FROM admin."optiuneResursaRol" WHERE "idRol" = $1 AND "idOptiuneResursa" = $2 AND ("access" != $3 OR "customAccess" != $4 OR "idItem" != $5 OR "descriere" != $6 OR "overrideDefaults" != $7)) THEN
			UPDATE admin."optiuneResursaRol" SET access = $3, "customAccess" = $4, "idItem" = $5, "descriere" = $6, "overrideDefaults" = $7 WHERE "idRol" = $1 AND "idOptiuneResursa" = $2;
		END IF;
	ELSE
		INSERT INTO admin."optiuneResursaRol"("idRol", "idOptiuneResursa", "access", "customAccess", "idItem", "descriere", "overrideDefaults") VALUES ($1, $2, $3, $4, $5, $6, $7);
	END IF;
	END;

$$;

alter function "actualizareOptiuneResursaRol"(integer, integer, boolean, varchar, integer, varchar, boolean) owner to postgres;

