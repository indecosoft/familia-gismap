create function "selectUserResource"(in_iduser integer, in_idclient integer)
    returns TABLE(id integer, nume character varying, descriere character varying, type character varying, "accessPermis" boolean, roles integer[], options character varying[])
    language sql
as
$$
set session "resource.idUser" = '1';
set session "resource.idClient" = '1';
with rs as 
        (
         select rr.id, rr."idRol", rr."idResursa", rr."access"  
         from admin."userRol" ur 
         join admin."resursaRol" rr
         on ur."idRol" = rr."idRol"
         JOIN admin."user" as u on u."username" = ur."username"
         where u."id" =  in_idUser and u."idClient" = in_idClient and rr."access" = true 
        ) 
        select res."id", res."nume", res."descriere", res."type", true as "accessPermis", --res."defaultAccess", res."customAccess", 
            array((select  rs."idRol"  from rs where rs."idResursa" = res."id" ) ) as roles, 
            array( 
				   select "nume" from admin."optiuneResursa" 
						where	"idResursa" = res.id 
								and (case when(("id" in (select "idOptiuneResursa" from admin."optiuneResursaRol" 
										where "access" = true and "idRol" in (select  rs."idRol"  from rs where rs."idResursa" = res."id" )))) then true
									else "defaultAccess" end)
                ) as options 
        from admin."resursa" as res 
        where res."id" in (select "idResursa" from rs)

$$;

alter function "selectUserResource"(integer, integer) owner to postgres;

