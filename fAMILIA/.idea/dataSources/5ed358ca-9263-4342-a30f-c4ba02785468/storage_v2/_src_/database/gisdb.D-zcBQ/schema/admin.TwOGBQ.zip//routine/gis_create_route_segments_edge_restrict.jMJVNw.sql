create function gis_create_route_segments_edge_restrict(in_route_id integer, id_judete integer[] DEFAULT NULL::integer[], restrict_type text DEFAULT NULL::text, directed boolean DEFAULT false)
    returns TABLE(o_route_id integer, o_seq integer, o_subroute_id integer, o_source integer, o_source_fr double precision, o_target_fr double precision, o_edge integer, o_name text, o_cost double precision, o_subroute_agg_cost double precision, o_route_agg_cost double precision, o_geom geometry, o_data_str character varying)
    language plpgsql
as
$$
declare
 id_judete_str text;
 ways_query text;
 rowcount integer;
 rr_rowcount record;
 rr_route record;
 rr_route_prev record;
 --rr_segment record;
 rr_edge record;
 	segment_route_id integer; 
	segment_source integer;
	segment_source_fr double precision;
	segment_target_fr double precision;
	segment_edge integer;
	segment_geom geometry;
	segment_length_m double precision;
	subroute_agg_length_m double precision;
	route_agg_length_m double precision;
	timenow TIMESTAMP;
begin

drop table if exists tb_route_segments ;
CREATE TEMP TABLE tb_route_segments (
		route_id integer,
		seq integer,
		subroute_id integer, 
		source integer,
		source_fr double precision,
		target_fr double precision,
		edge integer,
		name text,
		cost double precision,
		subroute_agg_cost double precision,
		route_agg_cost double precision,
		geom geometry,
		data_str character varying
);
----

ways_query := admin.gis_routing_ways_query_pg(id_judete,restrict_type);
--RAISE NOTICE ' way query  %', ways_query;

drop table if exists tb_point_data;
CREATE TEMP TABLE tb_point_data ON COMMIT DROP AS
	select ROW_NUMBER () OVER(order by seq) AS id, "routePoints".id as point_id, edge, fraction 
	from "routePoints" 
	where "idRoute" = in_route_id order by seq;

-- select ROW_NUMBER () over() as id, pos.meas_id, pos.edge, pos.fraction from device_position_to_route as pos 
-- 			join device_measurements as dv on pos.meas_id = dv.id 
-- 			where dv.imei = $1 and dv.data_str = $2 order by dv.ora_str asc;
			
---			
execute 'select count(*) as cnt from tb_point_data' into rr_rowcount;
rowcount :=rr_rowcount.cnt;
RAISE NOTICE 'tb_point_data row count( % )',  rowcount;
timenow := clock_timestamp();
RAISE NOTICE ' start timestamp %', timenow;
---
drop table if exists tb_point_route;
CREATE TEMP TABLE tb_point_route ON COMMIT DROP AS
SELECT r.seq, r.id1 As route_id, 
	r.id2 As node, r.id3 AS edge,
	r.cost, 
	(case when  r.id2 < 0  and r.id3 >= 0  then 
	 	--(select dd.fraction from tb_point_data as dd where dd.id = abs(r.id2) limit 1) 
	 	(select dd.fraction from tb_point_data as dd where dd.id = r.id1 limit 1) 
	 when r.id2 < 0 and r.id3 < 0 then
	 	(select dd.fraction from tb_point_data as dd where dd.id = r.id1 + 1 limit 1) 
	 else
	 	null
	 end 
	)::double precision as fraction
 from (SELECT * FROM pgr_trspViaEdges(
		ways_query,
		ARRAY( 
			select edge from tb_point_data order by id	asc															
		)::INTEGER[],
        ARRAY(
			select fraction from tb_point_data order by id asc
		)::FLOAT[] ,
        directed,
        true)
	   ) as r;
	   --
timenow := clock_timestamp();
RAISE NOTICE 'end route timestamp %', timenow;
---
execute 'select count(*) as cnt from tb_point_route' into rr_rowcount;
rowcount :=rr_rowcount.cnt;
--RAISE NOTICE 'tb_point_route row count( % )', rowcount;

---
rr_route_prev := row(null);
subroute_agg_length_m := 0.0;
route_agg_length_m := 0.0;
for rr_route in select * from tb_point_route order by seq asc loop
--RAISE NOTICE '% seq1', rr_route.seq;
if( rr_route.seq < 200000 and rr_route.seq > 1) then
	--RAISE NOTICE 'tb_point_route row %  %  prev % %',rr_route.seq, rr_route.route_id,rr_route_prev.seq, rr_route_prev.route_id;
	
	--first node in route
	if(rr_route.route_id = abs(rr_route.node)) then
		--RAISE NOTICE '% start point % ',rr_route.seq, rr_route.node;
	else 
		--d
		segment_edge := rr_route_prev.edge;
		--select segment from ways
		execute 'select * from ruteosm.ways where gid = '|| segment_edge ||'limit 1' into rr_edge;
		-- source point
		if(rr_route_prev.node < 0) then
		-- select source fraction from tb_point_data
			segment_source_fr := rr_route_prev.fraction;
		--	RAISE NOTICE '% src point on edge %  edge % fraction %',rr_route_prev.seq, rr_route_prev.node, segment_edge, segment_source_fr;
		elsif(rr_route_prev.node >=0) then
		--determine source fraction from edge of previous
			if rr_edge.source = rr_route_prev.node then
			 segment_source_fr := 0.0;
			else 
			 segment_source_fr := 1.0;
			end if;
		--RAISE NOTICE '% src point is vertex % edge % fraction %',rr_route_prev.seq, rr_route_prev.node,segment_edge, segment_source_fr;
		end if;
		-- target point
		if(rr_route.node < 0) then
		-- select target fraction from tb_point_data
			segment_target_fr := rr_route.fraction;
			--RAISE NOTICE '% trg point on edge %  edge % fraction %',rr_route.seq, rr_route.node, segment_edge, segment_target_fr;
		elsif(rr_route.node >= 0) then
		--determine target fraction from edge of previous
			if rr_edge.source = rr_route.node then
			 segment_target_fr := 0.0;
			else 
			 segment_target_fr := 1.0;
			end if;
		--RAISE NOTICE '% trg point is vertex % edge % fraction %',rr_route.seq, rr_route.node,segment_edge, segment_target_fr;
		end if;
		
		-- calculate geometry line
		if segment_source_fr < segment_target_fr then
			segment_geom := ST_LineSubstring(rr_edge.the_geom, segment_source_fr, segment_target_fr);
		else
			segment_geom := ST_LineSubstring(rr_edge.the_geom, segment_target_fr, segment_source_fr);
			segment_geom := ST_Reverse(segment_geom);
		end if;
		
		--
		if ST_GeometryType(segment_geom) = 'ST_Point' then
			segment_geom := ST_ShortestLine(segment_geom, segment_geom);
			segment_length_m := 0.0;
		else
			segment_length_m = ST_Length_Spheroid(segment_geom,'SPHEROID["WGS 84",6378137,298.257223563]');	   					   
		end if;
		--
		subroute_agg_length_m := subroute_agg_length_m + segment_length_m;
		route_agg_length_m := route_agg_length_m + segment_length_m;
		--
		segment_geom := ST_SetSRID(segment_geom, 4326);
		--RAISE NOTICE ' geometry %', ST_AsText(segment_geom);
		
		
		-- insert segment in table
		execute 'insert into tb_route_segments(route_id , seq, subroute_id, source, source_fr, target_fr, edge, name, cost, subroute_agg_cost, route_agg_cost, geom, data_str)'||
		'values('|| quote_literal(in_route_id) || ',  '||rr_route_prev.seq || ','|| rr_route_prev.route_id ||','||
		rr_route_prev.node||','||segment_source_fr||','||segment_target_fr||','||
		segment_edge||','|| quote_literal(rr_edge.name) ||','||segment_length_m||','||subroute_agg_length_m||','||route_agg_length_m||','||
		'ST_SetSRID('||quote_literal(ST_AsText(segment_geom))||'::geometry,4326)' ||
		', current_timestamp::text)';

	end if;
end if;
	rr_route_prev := rr_route;
end loop;
--
timenow := clock_timestamp();
RAISE NOTICE 'end timestamp %', timenow;
--return query select * from tb_point_route;
return query select * from tb_route_segments;

end

$$;

alter function gis_create_route_segments_edge_restrict(integer, integer[], text, boolean) owner to postgres;

