create function "trigger.log.rol"() returns trigger
    language plpgsql
as
$$
BEGIN
		if (current_setting('ctx.admin.rol.LogTrigger', 't') = 'ON') then
			return null;
		end if;
		set ctx.admin.rol.LogTrigger = 'ON';
		if  (TG_OP = 'INSERT') then
			update admin."rol"
				set username = admin."ctxUserName"()
			  	, stamp = now()
				where id = new.id;
    	end if;
    	if  (TG_OP = 'UPDATE') then
			update admin."rol" set username = admin."ctxUserName"(), stamp = now() where id = old.id ;
	 		insert into log."rol"(    "id" ,    "nume" ,    "descriere" ,    "idClient" , "username", "stamp")
				values(    old."id" ,    old."nume" ,    old."descriere" ,    old."idClient" , old."username", old."stamp");
			end if;
      if  (TG_OP = 'DELETE') then
			insert into log."rol"(    "id" ,    "nume" ,    "descriere" ,    "idClient" , "username", "stamp")
				values(    old."id" ,    old."nume" ,    old."descriere" ,    old."idClient" , old."username", old."stamp");
			insert into log."rol"(    "id" ,    "nume" ,    "descriere" ,    "idClient" , "username", "stamp")
				 values(    old."id" ,    old."nume" ,    old."descriere" ,    old."idClient" , admin."ctxUserName"(), now());
			end if;
			set ctx.admin.rol.LogTrigger = 'OFF';
  		return null;
	END;


$$;

alter function "trigger.log.rol"() owner to postgres;

