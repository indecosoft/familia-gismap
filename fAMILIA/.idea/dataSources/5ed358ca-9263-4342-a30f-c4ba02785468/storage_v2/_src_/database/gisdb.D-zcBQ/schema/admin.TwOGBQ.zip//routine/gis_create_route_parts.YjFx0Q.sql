create function gis_create_route_parts(route_id integer) returns integer
    language sql
as
$$
-- clear route parts
delete from public."routeParts" where "idRoute" = $1;

-- insert route parts
with rp as (select "idRoute", "subrouteId","seq", "cost", "geom" from public."routeSegments" where "idRoute" = $1 order by seq asc),
parts as (select "idRoute", "subrouteId","subrouteId" as "source", ("subrouteId" +1) as "target", max(seq), sum("cost") as "cost", public.st_makeline(geom) as "geom" from rp
group by "idRoute", "subrouteId"
order by "subrouteId" asc)
insert into public."routeParts"("idRoute", "idPart", "source", "target", "cost", "geom")
select "idRoute", "subrouteId", "source", "target", "cost", "geom" from parts;


select 1;

$$;

alter function gis_create_route_parts(integer) owner to postgres;

