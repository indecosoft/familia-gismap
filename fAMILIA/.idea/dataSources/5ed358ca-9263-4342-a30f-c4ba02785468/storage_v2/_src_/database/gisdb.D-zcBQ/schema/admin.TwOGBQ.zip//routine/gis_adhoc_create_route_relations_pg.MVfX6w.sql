create function gis_adhoc_create_route_relations_pg(route_id integer) returns integer
    language plpgsql
as
$$
declare
 var_status text;
begin
	--lock task and coresponding routes
	execute  'select * from public."routes" where "id" = $1 for update NOWAIT;' using route_id;
	execute 'select * from public."routePoints" where "idRoute" = $1 for update NOWAIT;' using route_id;
	--
	execute 'select admin.gis_create_route_relation_for_point("id", 0.1) from public."routePoints" where
	"idRoute" = $1;' using route_id;
	--
	execute 'update public.routes set status = $2, time = clock_timestamp() 
	where "id" = $1;' using route_id, 'rute_end_puncte_in_retea' ;
	--
	return 1;
end;

$$;

alter function gis_adhoc_create_route_relations_pg(integer) owner to postgres;

