create function gis_create_route_segments_intablesql_restrict(in_route_id integer, ids_judete integer[] DEFAULT NULL::integer[], restrict_type text DEFAULT NULL::text, directed boolean DEFAULT false) returns void
    language sql
as
$$
    --
--select createrouterelationforpoint(id, 0.5, $2) from route_points where route_id = $1;
--
delete from public."routeSegments" where "idRoute" = $1;
--
insert into "routeSegments"(
	"idRoute", "seq", "subrouteId", "source", "sourceFraction", "targetFraction", "edge", "name", "cost","aggCost", "routeAggCost", "geom", "dataStr"
)
select o_route_id, o_seq, o_subroute_id, o_source, o_source_fr, o_target_fr, o_edge, o_name, o_cost, o_subroute_agg_cost, o_route_agg_cost, o_geom, o_data_str
from  admin.gis_create_route_segments_edge_restrict($1, $2, $3, $4);


$$;

alter function gis_create_route_segments_intablesql_restrict(integer, integer[], text, boolean) owner to postgres;

