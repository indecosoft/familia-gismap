create view v_dispozitive_ruta(id, imei, dateiso, name, description, type, geom, "idClient") as
SELECT routes.id,
       routes.imei,
       routes.dateiso,
       routes.name,
       routes.description,
       routes.type,
       routes.geom,
       routes."idClient"
FROM routes
WHERE routes.type::text = 'dispozitiv_pe_zi'::text;

alter table v_dispozitive_ruta
    owner to postgres;

