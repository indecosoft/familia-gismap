create function st_geomfromgeojson(jsonb) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_GeomFromGeoJson($1::text)
$$;

comment on function st_geomfromgeojson(jsonb) is 'args: geomjson - Takes as input a geojson representation of a geometry and outputs a PostGIS geometry object';

alter function st_geomfromgeojson(jsonb) owner to postgres;

