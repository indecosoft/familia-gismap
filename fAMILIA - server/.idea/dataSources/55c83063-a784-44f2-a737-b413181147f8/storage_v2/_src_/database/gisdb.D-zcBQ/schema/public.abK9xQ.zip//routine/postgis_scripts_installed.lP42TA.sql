create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT '2.5.0'::text || ' r' || 16836::text AS version
$$;

comment on function postgis_scripts_installed() is 'Returns version of the postgis scripts installed in this database.';

alter function postgis_scripts_installed() owner to postgres;

