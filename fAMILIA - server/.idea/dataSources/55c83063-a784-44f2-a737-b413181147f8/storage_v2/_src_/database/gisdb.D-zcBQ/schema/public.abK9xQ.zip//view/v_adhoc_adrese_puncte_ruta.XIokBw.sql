create view v_adhoc_adrese_puncte_ruta
            (id, "idRoute", "idClient", seq, location, "strSource", strada, "numarPostal", localitate, judet) as
SELECT rp.id,
       rp."idRoute",
       ro."idClient",
       rp.seq,
       rp.location,
       rp."strSource",
       lc.strada,
       lc."numarPostal",
       lc.localitate,
       lc.judet
FROM "routePoints" rp
         JOIN routes ro ON rp."idRoute" = ro.id
         JOIN "locatieAdresa" lc ON rp."strSource"::text = lc."uuidNumarPostal"
WHERE ro.type::text = 'ad-hoc'::text
  AND ro."locationType"::text = 'uuid_address'::text;

alter table v_adhoc_adrese_puncte_ruta
    owner to postgres;

