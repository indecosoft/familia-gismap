create view "v_restrictWaysPath"
            (id, "clientId", "restrictType", "geomType", path, coeficient, description, active, timestamp) as
SELECT "restrictWays".id,
       "restrictWays"."clientId",
       "restrictWays"."restrictType",
       "restrictWays"."geomType",
       "restrictWays".path,
       "restrictWays".coeficient,
       "restrictWays".description,
       "restrictWays".active,
       "restrictWays"."timestamp"
FROM "restrictWays"
WHERE "restrictWays"."geomType"::text = 'lineString'::text;

alter table "v_restrictWaysPath"
    owner to postgres;

