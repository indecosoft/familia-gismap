create view v_adhoc_ruta(id, imei, dateiso, name, description, type, geom, "idClient", length) as
SELECT routes.id,
       routes.imei,
       routes.dateiso,
       routes.name,
       routes.description,
       routes.type,
       routes.geom,
       routes."idClient",
       routes.length
FROM routes
WHERE routes.type::text = 'ad-hoc'::text;

alter table v_adhoc_ruta
    owner to postgres;

