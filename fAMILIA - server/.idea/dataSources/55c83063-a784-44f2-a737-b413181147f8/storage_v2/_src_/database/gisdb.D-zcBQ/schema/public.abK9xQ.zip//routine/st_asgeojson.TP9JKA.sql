create function st_asgeojson(gj_version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4);
$$;

comment on function st_asgeojson(integer, geometry, integer, integer) is 'args: gj_version, geom, maxdecimaldigits=15, options=0 - Return the geometry as a GeoJSON element.';

alter function st_asgeojson(integer, geometry, integer, integer) owner to postgres;

