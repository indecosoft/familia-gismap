create view "v_asistentaSocialaCst"
            (id, client, cnp, nume, prenume, judet, localitate, strada, "numarPostal", "tipAjutor", "lunaAjutorLT",
             suma, "idClient", "idPersAsisoc", "codTipAjutor", "lunaAjutor", locatie)
as
SELECT so.id,
       cl.nume                                                                                                      AS client,
       NULL::text                                                                                                   AS cnp,
       NULL::text                                                                                                   AS nume,
       NULL::text                                                                                                   AS prenume,
       lo.judet,
       lo.localitate,
       lo.strada,
       lo."numarPostal",
       so."tipAjutor",
       to_char(timezone('Europe/Bucharest'::text,
                        so."lunaAjutor"::timestamp with time zone)::date::timestamp with time zone,
               'YYYYMM'::text)                                                                                      AS "lunaAjutorLT",
       so.suma,
       so."idClient",
       so."idPersAsisoc",
       so."codTipAjutor",
       so."lunaAjutor"::timestamp with time zone                                                                    AS "lunaAjutor",
       lo.locatie
FROM "asistentaSociala" so
         LEFT JOIN "locatieAdresa" lo ON so."uuidNumarPostal" = lo."uuidNumarPostal"
         LEFT JOIN admin.client cl ON cl.id = so."idClient";

alter table "v_asistentaSocialaCst"
    owner to postgres;

