create view v_adhoc_segmente_ruta
            ("idRoute", imei, dateiso, "idClient", id, seq, "subrouteId", "subrouteSeq", geom, source, "sourceFraction",
             "targetFraction", edge, cost, "aggCost", "routeAggCost")
as
SELECT rs."idRoute",
       ro.imei,
       ro.dateiso,
       ro."idClient",
       rs.id,
       rs.seq,
       rs."subrouteId",
       rs."subrouteSeq",
       rs.geom,
       rs.source,
       rs."sourceFraction",
       rs."targetFraction",
       rs.edge,
       rs.cost,
       rs."aggCost",
       rs."routeAggCost"
FROM "routeSegments" rs
         JOIN routes ro ON rs."idRoute" = ro.id
WHERE ro.type::text = 'ad-hoc'::text;

alter table v_adhoc_segmente_ruta
    owner to postgres;

