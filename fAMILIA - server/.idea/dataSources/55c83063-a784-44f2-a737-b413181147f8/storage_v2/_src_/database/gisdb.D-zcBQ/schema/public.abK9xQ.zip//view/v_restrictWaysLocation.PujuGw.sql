create view "v_restrictWaysLocation"
            (id, "clientId", "restrictType", "geomType", location, coeficient, description, active, timestamp) as
SELECT "restrictWays".id,
       "restrictWays"."clientId",
       "restrictWays"."restrictType",
       "restrictWays"."geomType",
       "restrictWays".location,
       "restrictWays".coeficient,
       "restrictWays".description,
       "restrictWays".active,
       "restrictWays"."timestamp"
FROM "restrictWays"
WHERE "restrictWays"."geomType"::text = 'point'::text;

alter table "v_restrictWaysLocation"
    owner to postgres;

