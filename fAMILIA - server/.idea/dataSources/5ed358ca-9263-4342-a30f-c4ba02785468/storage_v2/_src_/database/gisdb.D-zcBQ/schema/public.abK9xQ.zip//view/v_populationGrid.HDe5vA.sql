create view "v_populationGrid"
            (id0, grd_fixid, grd_floaid, grd_newid, method_cl, year, tot_p, tot_f, tot_m, f_00_14, f_15_64, f_65,
             m_00_14, m_15_64, m_65, id, ifcid, localid, namespace, versionid, nutscode, beginvers, endversion,
             shape_leng, shape_area, geom_b)
as
SELECT "PopulationGridNUTSCode".id0,
       "PopulationGridNUTSCode".grd_fixid,
       "PopulationGridNUTSCode".grd_floaid,
       "PopulationGridNUTSCode".grd_newid,
       "PopulationGridNUTSCode".method_cl,
       "PopulationGridNUTSCode".year,
       "PopulationGridNUTSCode".tot_p,
       "PopulationGridNUTSCode".tot_f,
       "PopulationGridNUTSCode".tot_m,
       "PopulationGridNUTSCode".f_00_14,
       "PopulationGridNUTSCode".f_15_64,
       "PopulationGridNUTSCode".f_65,
       "PopulationGridNUTSCode".m_00_14,
       "PopulationGridNUTSCode".m_15_64,
       "PopulationGridNUTSCode".m_65,
       "PopulationGridNUTSCode".id,
       "PopulationGridNUTSCode".ifcid,
       "PopulationGridNUTSCode".localid,
       "PopulationGridNUTSCode".namespace,
       "PopulationGridNUTSCode".versionid,
       "PopulationGridNUTSCode".nutscode,
       "PopulationGridNUTSCode".beginvers,
       "PopulationGridNUTSCode".endversion,
       "PopulationGridNUTSCode".shape_leng,
       "PopulationGridNUTSCode".shape_area,
       "PopulationGridNUTSCode".geom_b
FROM "PopulationGridNUTSCode";

alter table "v_populationGrid"
    owner to postgres;

