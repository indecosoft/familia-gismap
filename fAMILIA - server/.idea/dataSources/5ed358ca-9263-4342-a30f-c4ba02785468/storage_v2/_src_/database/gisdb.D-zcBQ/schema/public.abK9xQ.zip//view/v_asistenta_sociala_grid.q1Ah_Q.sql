create view v_asistenta_sociala_grid(count, sum, geom_b) as
WITH v_asis AS (
    SELECT so.id,
           so."uuidNumarPostal",
           so."idClient",
           so."idPersAsisoc",
           so."tipAjutor",
           so.suma,
           so."lunaAjutor"::timestamp with time zone AS "lunaAjutor",
           lo."numarPostal",
           lo.strada,
           lo.localitate,
           lo.judet,
           lo.locatie,
           NULL::text                                AS nume,
           NULL::text                                AS prenume,
           NULL::text                                AS cnp,
           to_char(timezone('Europe/Bucharest'::text,
                            so."lunaAjutor"::timestamp with time zone)::date::timestamp with time zone,
                   'YYYYMM'::text)                   AS "lunaAjutorLT",
           so."codTipAjutor"
    FROM "asistentaSociala" so
             LEFT JOIN "locatieAdresa" lo ON so."uuidNumarPostal" = lo."uuidNumarPostal"
)
SELECT count(a.id) AS count,
       sum(a.suma) AS sum,
       p.geom_b
FROM "PopulationGridNUTSCode" p
         JOIN v_asis a ON st_intersects(p.geom_b, a.locatie)
GROUP BY p.geom_b;

alter table v_asistenta_sociala_grid
    owner to postgres;

