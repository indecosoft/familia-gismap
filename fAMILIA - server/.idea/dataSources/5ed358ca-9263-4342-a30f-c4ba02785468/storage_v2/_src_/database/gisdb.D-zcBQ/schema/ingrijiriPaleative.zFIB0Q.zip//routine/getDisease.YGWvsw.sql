create function "getDisease"("idDiseaseP" uuid) returns json
    language plpgsql
as
$$
begin
	return
		(select row_to_json(r) from (select 
		d.id, 
		d.name boala, 
		(
			select array
			(
					select row_to_json(m) from (
						select dm.id, dm.name, dm.start "dataStart", dm.stop "dataStop", 
							(
								select array
								(
									select row_to_json(o) from 
									(
										select o.id, o.hour ora from "ingrijiriPaleative"."disease" d
											inner join "ingrijiriPaleative"."diseaseMed" dmo 
												on d.id = dmo."idDisease"
											inner join "ingrijiriPaleative"."diseaseHourMed" o
												on dmo.id = o."idMed"
											where o."idMed" = dm.id
									) o	
								)
							) ore from "ingrijiriPaleative"."disease" dd
								inner join "ingrijiriPaleative"."diseaseMed" dm
									on dd.id = dm."idDisease"
								where dm."idDisease" = d.id
					)m
			) medicamente
		) from "ingrijiriPaleative"."disease" d
		where d.id = $1
	) r);
end;
$$;

alter function "getDisease"(uuid) owner to postgres;

