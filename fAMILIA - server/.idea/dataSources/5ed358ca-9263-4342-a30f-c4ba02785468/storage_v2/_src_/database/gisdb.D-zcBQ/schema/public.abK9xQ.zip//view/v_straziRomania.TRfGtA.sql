create view "v_straziRomania"
            (id, geom, osm_id, code, fclass, name, ref, oneway, maxspeed, "Id", "localId", country, "natLevName",
             "natCode", localitate, "natCode_2", judet, "Shape_Leng")
as
SELECT "straziRomania".id,
       "straziRomania".geom,
       "straziRomania".osm_id,
       "straziRomania".code,
       "straziRomania".fclass,
       "straziRomania".name,
       "straziRomania".ref,
       "straziRomania".oneway,
       "straziRomania".maxspeed,
       "straziRomania"."Id",
       "straziRomania"."localId",
       "straziRomania".country,
       "straziRomania"."natLevName",
       "straziRomania"."natCode",
       "straziRomania".localitate,
       "straziRomania"."natCode_2",
       "straziRomania".judet,
       "straziRomania"."Shape_Leng"
FROM "straziRomania";

alter table "v_straziRomania"
    owner to postgres;

