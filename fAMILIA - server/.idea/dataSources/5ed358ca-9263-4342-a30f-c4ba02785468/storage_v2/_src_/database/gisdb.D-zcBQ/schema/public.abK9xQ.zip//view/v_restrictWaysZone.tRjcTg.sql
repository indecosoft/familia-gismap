create view "v_restrictWaysZone"
            (id, "clientId", "restrictType", "geomType", zone, coeficient, description, active, timestamp) as
SELECT "restrictWays".id,
       "restrictWays"."clientId",
       "restrictWays"."restrictType",
       "restrictWays"."geomType",
       "restrictWays".zone,
       "restrictWays".coeficient,
       "restrictWays".description,
       "restrictWays".active,
       "restrictWays"."timestamp"
FROM "restrictWays"
WHERE "restrictWays"."geomType"::text = 'polygon'::text;

alter table "v_restrictWaysZone"
    owner to postgres;

