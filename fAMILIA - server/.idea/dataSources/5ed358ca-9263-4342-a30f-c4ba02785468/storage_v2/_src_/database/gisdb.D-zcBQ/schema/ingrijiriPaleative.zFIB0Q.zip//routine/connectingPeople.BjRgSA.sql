create function "connectingPeople"("idFrom" integer, "idDest" integer) returns boolean
    language plpgsql
as
$$
BEGIN
                IF NOT EXISTS (SELECT 1 FROM "ingrijiriPaleative"."usersDataSharing" uds WHERE uds."idFrom" = $1 AND uds."idDest" = $2) THEN
                   INSERT INTO "ingrijiriPaleative"."usersDataSharing" ("idFrom", "idDest") 
                            VALUES ($1, $2);
                   return true;
                ELSE
                	return false;
                END IF;
END;

$$;

alter function "connectingPeople"(integer, integer) owner to postgres;

