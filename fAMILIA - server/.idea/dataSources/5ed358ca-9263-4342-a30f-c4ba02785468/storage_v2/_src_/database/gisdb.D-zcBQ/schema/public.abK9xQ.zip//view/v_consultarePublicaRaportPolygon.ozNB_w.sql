create view "v_consultarePublicaRaportPolygon"
            (id, "idClient", "tipConsultare", descriere, rate, "geomPolygon", total) as
SELECT "consultarePublicaRaport".id,
       "consultarePublicaRaport"."idClient",
       "consultarePublicaRaport"."tipConsultare",
       "consultarePublicaRaport".descriere,
       "consultarePublicaRaport".rate,
       "consultarePublicaRaport"."geomPolygon",
       "consultarePublicaRaport".total
FROM "consultarePublicaRaport";

alter table "v_consultarePublicaRaportPolygon"
    owner to postgres;

