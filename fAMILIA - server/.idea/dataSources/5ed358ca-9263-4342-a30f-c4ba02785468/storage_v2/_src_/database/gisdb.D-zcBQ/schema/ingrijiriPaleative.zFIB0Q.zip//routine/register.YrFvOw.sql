create function register(input_email character varying, input_password character varying, input_nume character varying, input_imei character varying) returns boolean
    language plpgsql
as
$$
DECLARE
	"idClientV" integer;
	"idPersoanaV" integer;
	"assistantV" boolean;
    salt UUID;
BEGIN
    salt := uuid_generate_v4();
    IF (SELECT COUNT(*)FROM "ingrijiriPaleative".users WHERE email = input_email) = 0 THEN
	select "idClient", "idPersoana", assistant into "idClientV", "idPersoanaV", "assistantV" from admin."deviceConfig" WHERE imei = $4 order by id desc limit 1;
		if ("idClientV" is not null) and ("idPersoanaV" is not null) and ("assistantV" is not null) then
			if ("assistantV" = true) then
				insert into "ingrijiriPaleative".users("idClient", email, password, salt, imei, tip, nume, "idPersAsisoc")
					values ("idClientV", $1, MD5($2 || salt), salt, $4, 2, $3, "idPersoanaV");
			else
				insert into "ingrijiriPaleative".users("idClient", email, password, salt, imei, tip, nume, "idPersAsisoc")
					values ("idClientV", $1, MD5($2 || salt), salt, $4, 3, $3, "idPersoanaV");
			end if;
		else
			insert into "ingrijiriPaleative".users("idClient", email, password, salt, imei, tip, nume, "idPersAsisoc")
				values ("idClientV", $1, MD5($2 || salt), salt, $4, 4, $3, "idPersoanaV");
		end if;
		RETURN TRUE;
    ELSE
    	RETURN FALSE;
    END IF;
    END;


$$;

alter function register(varchar, varchar, varchar, varchar) owner to postgres;

