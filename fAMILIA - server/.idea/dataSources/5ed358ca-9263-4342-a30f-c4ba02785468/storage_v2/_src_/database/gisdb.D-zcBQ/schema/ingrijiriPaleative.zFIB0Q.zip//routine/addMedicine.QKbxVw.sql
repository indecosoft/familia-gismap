create function "addMedicine"("idClientP" integer, "idPersAsisocP" integer, medicine json[]) returns void
    language plpgsql
as
$$
declare
	size integer := array_length(medicine, 1);
	"idUserP" integer := (select id from "ingrijiriPaleative".users where "idClient" = $1 AND "idPersAsisoc" = $2 order by id desc limit 1);
begin
	if size is null then
		RAISE EXCEPTION 'Empty array %', medicine::text USING ERRCODE = '23505';
	end if;
 	for i in 1..size loop
		if ((select count(*) from "ingrijiriPaleative"."usersMedicine" where "idUser" = "idUserP" and timestamp = to_timestamp(medicine[I]->>'stamp', 'YYYY-MM-DD hh24:mi:ss') and title = medicine[i]->>'title' and content = medicine[i]->>'content' and postpone = (medicine[i]->>'postpone')::int) = 0) then
 		insert into "ingrijiriPaleative"."usersMedicine" (uuid, "idUser", timestamp, title, content, postpone, "idMedAsisoc")
 			values (uuid_generate_v4(), "idUserP", to_timestamp(medicine[I]->>'stamp', 'YYYY-MM-DD hh24:mi:ss'), medicine[i]->>'title', medicine[i]->>'content', (medicine[i]->>'postpone')::int, (medicine[i]->>'idMedAsisoc')::int);
		end if;
 	end loop;
end;

$$;

alter function "addMedicine"(integer, integer, json[]) owner to postgres;

