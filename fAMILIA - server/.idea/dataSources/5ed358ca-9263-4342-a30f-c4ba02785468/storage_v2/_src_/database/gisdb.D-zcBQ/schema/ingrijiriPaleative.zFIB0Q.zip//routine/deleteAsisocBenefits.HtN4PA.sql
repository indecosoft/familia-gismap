create function "deleteAsisocBenefits"(element json) returns text
    language plpgsql
as
$$
declare
	"idPacient" int;
	"idAsistent" int;
	"message" text := 'deleted';
begin
		if ("element"->>'idClientAsistent' is not null 
				and "element"->>'idPersAsisocAsistent' is not null
		   		and "element"->>'idClientPacient' is not null
		   		and "element"->>'idPersAsisocPacient' is not null
		   		and "element"->>'idBeneficiu' is not null
		   		and "element"->>'dataStart' is not null
		   		and "element"->>'dataStop' is not null) then
			"idPacient" := (select id from "ingriiriPaleative".users 
								where "idClient" = "element"->>'idClientPacient'::int
									and "idPacient" = "element"->>'idPersAsisocPacient'::int
								limit 1
						   );
			"idAsistent" := (select id from "ingriiriPaleative".users 
								where "idClient" = "element"->>'idClientAsistent'::int
									and "idPacient" = "element"->>'idPersAsisocAsistent'::int
							 	limit 1
						   );
						   
			if ("idPacient" is not null and "idAsistent" is not null) then
				delete from "ingrijriPaleative"."usersAsisocBenefits" ub
					where ub."idAsistent" = "idAsistent"
						and ub."idPacient" = "idPacient"
						and ub."idBeneficiu" = "element"->>'idBeneficiu'::int
						and ub."dataStart" = date("element"->>'dataStart')
						and ub."dataStop" = date("element"->>'dataStop');
			else
				"message" := 'Pacientul/Asistentul nu exista in db.';
				rollback;
			end if;
		else
			"message" := 'Datele sunt incomplete: ' || "element"::json;
			rollback;
		end if;
	
	return "message";
	
	exception when others then 
		return "message";
end;
$$;

alter function "deleteAsisocBenefits"(json) owner to postgres;

