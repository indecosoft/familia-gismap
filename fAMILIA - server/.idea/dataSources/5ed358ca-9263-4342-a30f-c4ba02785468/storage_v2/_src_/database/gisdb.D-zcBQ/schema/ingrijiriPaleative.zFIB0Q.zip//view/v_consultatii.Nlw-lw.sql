create view v_consultatii
            (id, "idAsistent", "idPacient", "oraStart", "oraStop", activitati, detalii, locatie, "idClient",
             "idPersAsisoc") as
SELECT c.id,
       c."idAsistent",
       c."idPacient",
       c."oraStart",
       c."oraStop",
       c.activitati,
       c.detalii,
       c.locatie,
       u."idClient",
       u."idPersAsisoc"
FROM "ingrijiriPaleative".consultatii c
         JOIN "ingrijiriPaleative".users u ON c."idPacient" = u.id;

alter table v_consultatii
    owner to postgres;

