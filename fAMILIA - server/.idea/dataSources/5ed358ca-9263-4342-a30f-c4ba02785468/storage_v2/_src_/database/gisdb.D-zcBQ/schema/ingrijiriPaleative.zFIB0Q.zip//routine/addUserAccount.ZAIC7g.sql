create function "addUserAccount"(input_email character varying, input_password character varying, input_nume character varying, input_type integer, input_imei character varying, input_idclient integer) returns boolean
    language plpgsql
as
$$
DECLARE
      ref refcursor;
      salt UUID;
    BEGIN
    salt := uuid_generate_v4();
    IF (SELECT COUNT(*)FROM "ingrijiriPaleative".users WHERE email = input_email) = 0 THEN
    	IF input_type = 4 THEN
    		INSERT INTO "ingrijiriPaleative"."users" (email, password, salt, imei, tip, nume) VALUES (input_email, MD5(input_password || salt) ,salt , input_imei, 4, input_nume);
        ELSE
        	INSERT INTO "ingrijiriPaleative"."users" ("idClient", email, password, salt, imei, tip, nume) VALUES (input_idclient, input_email, MD5(input_password || salt) ,salt , input_imei, input_type, input_nume);
        END IF;
        RETURN true;
    ELSE
    	RETURN FALSE;
    END IF;
    END;


$$;

alter function "addUserAccount"(varchar, varchar, varchar, integer, varchar, integer) owner to postgres;

