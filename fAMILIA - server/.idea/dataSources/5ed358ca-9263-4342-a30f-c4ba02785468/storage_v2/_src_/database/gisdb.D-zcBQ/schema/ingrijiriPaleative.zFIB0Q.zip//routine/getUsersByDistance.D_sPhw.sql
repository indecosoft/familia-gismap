create function "getUsersByDistance"("selfId" integer, "friendId" integer, distance integer)
    returns TABLE(email character varying, nume character varying, avatar character varying)
    language plpgsql
as
$$
BEGIN
         RETURN QUERY
         (SELECT u.email, u.nume, u.avatar FROM "ingrijiriPaleative".users u INNER JOIN "ingrijiriPaleative"."usersLocation" ul ON u.id = ul."idUser" WHERE u.id = $1 AND 
    	(SELECT ST_Distance(ST_Point((SELECT ST_X(ST_Transform(location, 3857)) FROM "ingrijiriPaleative"."usersLocation" WHERE "idUser" = $1), (SELECT ST_Y (ST_Transform (location, 3857)) FROM "ingrijiriPaleative"."usersLocation" WHERE "idUser" = $1))::geography,
       		ST_Point((SELECT ST_X(ST_Transform(location, 3857)) FROM "ingrijiriPaleative"."usersLocation" WHERE "idUser" = $2), (SELECT ST_Y (ST_Transform (location, 3857)) FROM "ingrijiriPaleative"."usersLocation" WHERE "idUser" = $2))::geography) as distance) <= $3
            AND (SELECT (SELECT ARRAY(SELECT "idDisease" FROM "ingrijiriPaleative"."usersDiseases" WHERE "idUser" = $2))::int[] && ((SELECT ARRAY(SELECT "idDisease" FROM "ingrijiriPaleative"."usersDiseases" WHERE "idUser" = $1))::int[]) != false));

       
END

$$;

alter function "getUsersByDistance"(integer, integer, integer) owner to postgres;

