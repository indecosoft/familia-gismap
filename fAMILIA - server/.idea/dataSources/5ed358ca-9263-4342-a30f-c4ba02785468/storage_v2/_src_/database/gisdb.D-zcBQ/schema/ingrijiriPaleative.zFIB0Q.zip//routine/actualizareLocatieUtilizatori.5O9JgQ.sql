create function "actualizareLocatieUtilizatori"("idUser" integer, location character varying) returns void
    language plpgsql
as
$$
BEGIN
                IF EXISTS (SELECT 1 FROM "ingrijiriPaleative"."usersLocation" ul WHERE ul."idUser" = $1) THEN
                   UPDATE "ingrijiriPaleative"."usersLocation" SET "location" = ST_SetSRID(ST_GeomFromText($2), 3857)
                            WHERE "ingrijiriPaleative"."usersLocation"."idUser" = $1;
                ELSE 
                   INSERT INTO "ingrijiriPaleative"."usersLocation" ("idUser", "location") 
                            VALUES ($1, ST_SetSRID(ST_GeomFromText($2), 3857));
                END IF;
END;

$$;

alter function "actualizareLocatieUtilizatori"(integer, varchar) owner to postgres;

