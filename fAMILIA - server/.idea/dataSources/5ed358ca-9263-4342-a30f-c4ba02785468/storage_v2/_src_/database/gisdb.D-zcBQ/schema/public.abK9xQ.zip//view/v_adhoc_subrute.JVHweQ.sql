create view v_adhoc_subrute (id, "idRoute", "idPart", source, target, cost, "aggCost", geom, "idClient") as
SELECT rp.id,
       rp."idRoute",
       rp."idPart",
       rp.source,
       rp.target,
       rp.cost,
       rp."aggCost",
       rp.geom,
       ro."idClient"
FROM "routeParts" rp
         JOIN routes ro ON rp."idRoute" = ro.id
WHERE ro.type::text = 'ad-hoc'::text;

alter table v_adhoc_subrute
    owner to postgres;

