create function "addTreatment"(treatment json) returns text
    language plpgsql
as
$$
declare
	"idUserP" integer;
	"diseaseP" json[];
	"diseaseId" uuid;
	"diseaseLength" integer;
	"med" json[];
	"medId" uuid;
	"medLength" integer;
	"medH" json[];
	"medHLength" integer;
begin
	"idUserP" := (select id from "ingrijiriPaleative".users where "idClient" = (treatment->>'idClient')::integer AND "idPersAsisoc" = (treatment->>'idPersAsisoc')::integer LIMIT 1);
	"diseaseP" := array(select json_array_elements_text((treatment->>'data')::json));
	"diseaseLength" := array_length("diseaseP", 1);
	
  	if "idUserP" IS NULL then
  		return false;
  	else
   		for i in 1..coalesce("diseaseLength", 0) loop
   			"diseaseId" := uuid_generate_v4();
			if ((select count(*) from "ingrijiriPaleative".disease where "idBoalaAsisoc" = ("diseaseP"[i]->>'idBoalaAsisoc')::int and "idUser" = "idUserP" limit 1) = 0) then
				insert into "ingrijiriPaleative".disease(id, name, "idUser", "idBoalaAsisoc") values ("diseaseId", "diseaseP"[i]->>'boala', "idUserP", ("diseaseP"[i]->>'idBoalaAsisoc')::int);
			else
				"diseaseId" = (select id from "ingrijiriPaleative".disease where "idBoalaAsisoc" = ("diseaseP"[i]->>'idBoalaAsisoc')::int and "idUser" = "idUserP" limit 1);
			end if;
			med := array(select json_array_elements_text(("diseaseP"[i]->>'medicamente')::json));
			"medLength" := array_length(med, 1);
			for j in 1..coalesce("medLength", 0) loop
				delete from "ingrijiriPaleative"."usersMedicine" 
					where "idUser" = "idUserP" and "idMedAsisoc" = (med[j]->>'idMedAsisoc')::int and timestamp >= now() and taken is null;
				"medId" := uuid_generate_v4();
				if ((select count(*) from "ingrijiriPaleative"."diseaseMed" where "idMedAsisoc" = (med[j]->>'idMedAsisoc')::int and "idDisease" = "diseaseId" limit 1) = 0) then
					insert into "ingrijiriPaleative"."diseaseMed"(id, name, start, stop, "idDisease", "idMedAsisoc") 
						values ("medId", med[j]->>'denumire', (med[j]->>'dataStart')::date, (med[j]->>'dataStop')::date, "diseaseId", (med[j]->>'idMedAsisoc')::int);
				else
					"medId" = (select id from "ingrijiriPaleative"."diseaseMed" where "idMedAsisoc" = (med[j]->>'idMedAsisoc')::int and "idDisease" = "diseaseId" limit 1);
				end if;
				"medH" = array(select json_array_elements_text((med[j]->>'ore')::json));
				"medHLength" := array_length("medH", 1);
				for k in 1..coalesce("medHLength", 0) loop
					delete from "ingrijiriPaleative"."diseaseHourMed" where hour = "medH"[k]->>'ora' and "idMed" = "medId";
					insert into "ingrijiriPaleative"."diseaseHourMed"(id, hour, "idMed") values (uuid_generate_v4(), "medH"[k]->>'ora', "medId");										 
				end loop;
			end loop;
   		end loop;
  		return true;
  	end if;
end;
$$;

alter function "addTreatment"(json) owner to postgres;

