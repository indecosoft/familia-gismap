create function "userLogin"(input_email character varying, input_password character varying, input_imei character varying) returns text
    language plpgsql
as
$$
DECLARE
		"idClientV" integer;
		"idPersoanaV" integer;
		"idClientC" integer;
		"idPersoanaC" integer;
		"dataStartC" date;
    BEGIN
    IF (SELECT COUNT(*) FROM "ingrijiriPaleative".users WHERE email = input_email AND password = MD5(input_password || (SELECT salt from "ingrijiriPaleative".users WHERE email = input_email))) = 1 THEN
    	select "idClient", "idPersAsisoc" into "idClientV", "idPersoanaV" from "ingrijiriPaleative".users where email = input_email and imei = input_imei;
		if ("idClientV" is not null) and ("idPersoanaV" is not null) then
			select max("idClient"), max("idPersoana"), max("dataStart") "dataStart" INTO "idClientC", "idPersoanaC", "dataStartC"
				from admin."deviceConfig" where imei = input_imei and "dataStop" is null;
			if ("idClientC" is null) and ("idPersoanaC" is null) and ("dataStartC" is null) then
				return 2;
			end if;
			
			if ("idClientV" = "idClientC") AND ("idPersoanaV" = "idPersoanaC") then
				return 2;
			else
				return (5 || '|||' || "idPersoanaC");
			end if;
		else
			IF EXISTS (SELECT 1 FROM "ingrijiriPaleative".users WHERE email = input_email AND imei = input_imei) THEN
        		RETURN 2;
        	ELSE
        		RETURN 3;
        	END IF;
		end if;
    ELSE
    	RETURN 4;
    END IF;
    END;
    
	
-- SELECT "ingrijiriPaleative"."userLogin"('ovidiu.podina96@gmail.com', 'Test1234', '354889106584095')

$$;

alter function "userLogin"(varchar, varchar, varchar) owner to postgres;

