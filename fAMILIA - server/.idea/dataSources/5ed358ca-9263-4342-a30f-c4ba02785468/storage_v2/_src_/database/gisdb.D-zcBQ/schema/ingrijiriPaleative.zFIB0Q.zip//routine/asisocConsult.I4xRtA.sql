create function "asisocConsult"(data json) returns json[]
    language plpgsql
as
$$
declare
	"imeiP" text;
	tip boolean;
begin
	if ("data"->>'idClient' is not null) and ("data"->>'idPersAsisoc' is not null) and ("data"->>'start' is not null) and ("data"->>'stop' is not null) then
		select dc.imei, dc.assistant into "imeiP", tip
			from admin."deviceConfig" dc
			inner join "ingrijiriPaleative".users u on u.imei = dc.imei
			where dc."idClient" = ("data"->>'idClient')::int and dc."idPersoana" = ("data"->>'idPersAsisoc')::int and "dataStop" is null
			order by "dataStart" desc limit 1;
		if ("data"->>'tip' is not null) then
			if (tip = true) then
				return (select(select array(select row_to_json(res) from (
					select c.id, st_x(c.locatie) long, st_y(c.locatie) lat, u."idClient", (select "idPersAsisoc" from "ingrijiriPaleative".users where id = c."idPacient") as "idPersAsisoc", c."oraStart", c."oraStop", c.detalii, c.activitati from "ingrijiriPaleative".consultatii c
						inner join "ingrijiriPaleative".users u on u.id = c."idAsistent"
						where c."idAsistent" = (select id from "ingrijiriPaleative".users iu where iu.imei = "imeiP")
							AND "data"->>'tip' = any(c.activitati)
							AND date(c."oraStart") >= date("data"->>'start')
							AND date(c."oraStop") <= date("data"->>'stop')
				)res)));
			else
				return (select(select array(select row_to_json(res) from (
					select c.id, st_x(c.locatie) long, st_y(c.locatie) lat, u."idClient", (select "idPersAsisoc" from "ingrijiriPaleative".users where id = c."idAsistent") as "idPersAsisoc", c."oraStart", c."oraStop", c.detalii, c.activitati from "ingrijiriPaleative".consultatii c
						inner join "ingrijiriPaleative".users u on u.id = c."idPacient"
						where c."idPacient" = (select id from "ingrijiriPaleative".users iu where iu.imei = "imeiP")
							AND "data"->>'tip' = any(c.activitati)
							AND date(c."oraStart") >= date("data"->>'start')
							AND date(c."oraStop") <= date("data"->>'stop')
				)res)));
			end if;
		else
			if (tip = true) then
				return (select(select array(select row_to_json(res) from (
					select c.id, st_x(c.locatie) long, st_y(c.locatie) lat, u."idClient", (select "idPersAsisoc" from "ingrijiriPaleative".users where id = c."idPacient") as "idPersAsisoc", c."oraStart", c."oraStop", c.detalii, c.activitati from "ingrijiriPaleative".consultatii c
						inner join "ingrijiriPaleative".users u on u.id = c."idAsistent"
						where c."idAsistent" = (select id from "ingrijiriPaleative".users iu where iu.imei = "imeiP")
							AND date(c."oraStart") >= date("data"->>'start')
							AND date(c."oraStop") <= date("data"->>'stop')
				)res)));
			else
				return (select(select array(select row_to_json(res) from (
					select c.id, st_x(c.locatie) long, st_y(c.locatie) lat, u."idClient", (select "idPersAsisoc" from "ingrijiriPaleative".users where id = c."idAsistent") as "idPersAsisoc", c."oraStart", c."oraStop", c.detalii, c.activitati from "ingrijiriPaleative".consultatii c
						inner join "ingrijiriPaleative".users u on u.id = c."idPacient"
						where c."idPacient" = (select id from "ingrijiriPaleative".users iu where iu.imei = "imeiP")
							AND date(c."oraStart") >= date("data"->>'start')
							AND date(c."oraStop") <= date("data"->>'stop')
				)res)));
			end if;
		end if;
	end if;
	return null;
end;
$$;

alter function "asisocConsult"(json) owner to postgres;

