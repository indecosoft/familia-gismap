create view "v_restrictWaysWithSegments"
            (id, "restrictWayId", "waySegment", "segmentId", "clientId", "restrictType", "geomType", coeficient,
             description, active, timestamp)
as
SELECT rs.id,
       rs."restrictWayId",
       rs."waySegment",
       rs."segmentId",
       rr."clientId",
       rr."restrictType",
       rr."geomType",
       rr.coeficient,
       rr.description,
       rr.active,
       rr."timestamp"
FROM "restrictWays" rr
         LEFT JOIN "restrictWaysSegment" rs ON rr.id = rs."restrictWayId"
ORDER BY rr.id, rs.id;

alter table "v_restrictWaysWithSegments"
    owner to postgres;

