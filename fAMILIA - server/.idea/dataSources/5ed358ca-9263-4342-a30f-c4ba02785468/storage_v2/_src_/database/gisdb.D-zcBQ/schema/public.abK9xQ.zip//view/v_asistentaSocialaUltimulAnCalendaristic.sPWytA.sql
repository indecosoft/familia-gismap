create view "v_asistentaSocialaUltimulAnCalendaristic"
            (id, "uuidNumarPostal", "idClient", "idPersAsisoc", "tipAjutor", suma, "lunaAjutor", "numarPostal", strada,
             localitate, judet, locatie, nume, prenume, cnp, "lunaAjutorLT", "codTipAjutor")
as
SELECT so.id,
       so."uuidNumarPostal",
       so."idClient",
       so."idPersAsisoc",
       so."tipAjutor",
       so.suma,
       so."lunaAjutor"::timestamp with time zone                                                                    AS "lunaAjutor",
       lo."numarPostal",
       lo.strada,
       lo.localitate,
       lo.judet,
       lo.locatie,
       NULL::text                                                                                                   AS nume,
       NULL::text                                                                                                   AS prenume,
       NULL::text                                                                                                   AS cnp,
       to_char(timezone('Europe/Bucharest'::text,
                        so."lunaAjutor"::timestamp with time zone)::date::timestamp with time zone,
               'YYYYMM'::text)                                                                                      AS "lunaAjutorLT",
       so."codTipAjutor"
FROM "asistentaSociala" so
         LEFT JOIN "locatieAdresa" lo ON so."uuidNumarPostal" = lo."uuidNumarPostal"
WHERE date_part('year'::text, so."lunaAjutor") <= (date_part('year'::text, CURRENT_DATE) - 1::double precision);

alter table "v_asistentaSocialaUltimulAnCalendaristic"
    owner to postgres;

