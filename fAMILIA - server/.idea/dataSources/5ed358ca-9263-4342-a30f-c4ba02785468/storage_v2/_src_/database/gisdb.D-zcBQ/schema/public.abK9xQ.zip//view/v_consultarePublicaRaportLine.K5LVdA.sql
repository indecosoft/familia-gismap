create view "v_consultarePublicaRaportLine"(id, "idClient", "tipConsultare", descriere, rate, "geomLine", total) as
SELECT "consultarePublicaRaport".id,
       "consultarePublicaRaport"."idClient",
       "consultarePublicaRaport"."tipConsultare",
       "consultarePublicaRaport".descriere,
       "consultarePublicaRaport".rate,
       "consultarePublicaRaport"."geomLine",
       "consultarePublicaRaport".total
FROM "consultarePublicaRaport";

alter table "v_consultarePublicaRaportLine"
    owner to postgres;

