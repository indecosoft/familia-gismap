create view v_adhoc_puncte_ruta ("idRoute", imei, dateiso, "idClient", id, seq, geom, edge, fraction, vertex) as
SELECT rp."idRoute",
       ro.imei,
       ro.dateiso,
       ro."idClient",
       rp.id,
       rp.seq,
       rp.geom,
       rp.edge,
       rp.fraction,
       rp.vertex
FROM "routePoints" rp
         JOIN routes ro ON rp."idRoute" = ro.id
WHERE ro.type::text = 'ad-hoc'::text;

alter table v_adhoc_puncte_ruta
    owner to postgres;

