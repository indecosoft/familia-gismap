create function "deleteMedicine"("idClientP" integer, "idPers" integer, "idBoala" integer, "idMedP" integer) returns void
    language plpgsql
as
$$
begin
	if ("idBoala") is not null then
		delete from "ingrijiriPaleative"."usersMedicine" where "idUser" = (select id from "ingrijiriPaleative".users where "idClient" = $1 and "idPersAsisoc" = $2)
			and "idMedAsisoc" in (select "idMedAsisoc" from "ingrijiriPaleative"."diseaseMed" dm
								  	inner join "ingrijiriPaleative"."disease" d on d.id = dm."idDisease"
								  	where d."idBoalaAsisoc" = "idBoala");
		delete from "ingrijiriPaleative"."diseaseHourMed" 
			where "idMed" in
				(select id from "ingrijiriPaleative"."diseaseMed" 
				 	where "idDisease" = 
				 		(select id from "ingrijiriPaleative".disease 
						 	where "idBoalaAsisoc" = "idBoala" and "idUser" = 
						 		(select id from "ingrijiriPaleative".users where "idClient" = $1 and "idPersAsisoc" = $2)));
		delete from "ingrijiriPaleative"."diseaseMed"
			where "idDisease" in (select id from "ingrijiriPaleative".disease where "idBoalaAsisoc" = "idBoala" and "idUser" = (select id from "ingrijiriPaleative".users where "idClient" = $1 and "idPersAsisoc" = $2));
		delete from "ingrijiriPaleative".disease where "idBoalaAsisoc" = "idBoala" and "idUser" = (select id from "ingrijiriPaleative".users where "idClient" = $1 and "idPersAsisoc" = $2);
	end if;
	if ("idMedP") is not null then
		delete from "ingrijiriPaleative"."diseaseHourMed"
			where "idMed" in (select id from "ingrijiriPaleative"."diseaseMed" where "idMedAsisoc" = $4);
		delete from "ingrijiriPaleative"."diseaseMed" where "idMedAsisoc" = $4;
		delete from  "ingrijiriPaleative"."usersMedicine" where "idMedAsisoc" = $4 and "idUser" = (select id from "ingrijiriPaleative".users where "idClient" = $1 and "idPersAsisoc" = $2);
	end if;
end;
$$;

alter function "deleteMedicine"(integer, integer, integer, integer) owner to postgres;

