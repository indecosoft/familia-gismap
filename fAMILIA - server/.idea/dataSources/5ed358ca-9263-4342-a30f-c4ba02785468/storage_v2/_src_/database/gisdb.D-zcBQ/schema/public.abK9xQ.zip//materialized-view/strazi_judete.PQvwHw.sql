create materialized view strazi_judete as
SELECT wa.gid,
       wa.class_id,
       wa.length,
       wa.length_m,
       wa.name,
       wa.source,
       wa.target,
       wa.x1,
       wa.y1,
       wa.x2,
       wa.y2,
       wa.cost,
       wa.reverse_cost,
       wa.cost_s,
       wa.reverse_cost_s,
       wa.rule,
       wa.one_way,
       wa.maxspeed_forward,
       wa.maxspeed_backward,
       wa.osm_id,
       wa.source_osm,
       wa.target_osm,
       wa.priority,
       wa.the_geom,
       (SELECT "administrativeUnit2ndLevel".id
        FROM "administrativeUnit2ndLevel"
        WHERE st_contains("administrativeUnit2ndLevel".geom, wa.the_geom)) AS id_judet
FROM ruteosm.ways wa;

alter materialized view strazi_judete owner to postgres;

