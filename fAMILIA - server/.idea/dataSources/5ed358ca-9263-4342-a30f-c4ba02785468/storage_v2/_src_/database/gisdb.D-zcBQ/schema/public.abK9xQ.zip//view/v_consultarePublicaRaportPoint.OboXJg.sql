create view "v_consultarePublicaRaportPoint"(id, "idClient", "tipConsultare", descriere, rate, "geomPoint", total) as
SELECT "consultarePublicaRaport".id,
       "consultarePublicaRaport"."idClient",
       "consultarePublicaRaport"."tipConsultare",
       "consultarePublicaRaport".descriere,
       "consultarePublicaRaport".rate,
       "consultarePublicaRaport"."geomPoint",
       "consultarePublicaRaport".total
FROM "consultarePublicaRaport";

alter table "v_consultarePublicaRaportPoint"
    owner to postgres;

