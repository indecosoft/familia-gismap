create function "addAsisocBenefits"(benefits json[]) returns text
    language plpgsql
as
$$
declare
	"size" integer := array_length(benefits, 1);
	"element" json;
	"idPacient" int;
	"idAsistent" int;
	"message" text := 'saved';
begin
	for i in 1.."size" loop
		"element" := benefits[i]::json;
		if ("element"->>'idClientAsistent' is not null 
				and "element"->>'idPersAsisocAsistent' is not null
		   		and "element"->>'idClientPacient' is not null
		   		and "element"->>'idPersAsisocPacient' is not null
		   		and "element"->>'idBeneficiu' is not null
		   		and "element"->>'dataStart' is not null
		   		and "element"->>'dataStop' is not null
		   		and "element"->>'frecventa' is not null) then
			"idPacient" := (select id from "ingriiriPaleative".users 
								where "idClient" = "element"->>'idClientPacient'::int
									and "idPacient" = "element"->>'idPersAsisocPacient'::int
								limit 1
						   );
			"idAsistent" := (select id from "ingriiriPaleative".users 
								where "idClient" = "element"->>'idClientAsistent'::int
									and "idPacient" = "element"->>'idPersAsisocAsistent'::int
							 	limit 1
						   );
						   
			if ("idPacient" is not null and "idAsistent" is not null) then
				insert into "ingrijiriPaleative"."usersAsisocBenefits" ("idAsistent", "idPacient", "idBeneficiu", "dataStart", "dataStop", frecventa)
					values ("idAsistent", "idPacient", "element"->>'idBeneficiu'::int, date("element"->>'dataStart'), date("element"->>'dataStop'), "element"->>'frecventa'::int);
			else
				"message" := 'Pacientul/Asistentul nu exista in db.';
				rollback;
			end if;
		else
			"message" := 'Datele sunt incomplete: ' || "element"::json;
			rollback;
		end if;
	end loop;
	
	return "message";
	
	exception when others then 
		return "message";
end;
$$;

alter function "addAsisocBenefits"(json[]) owner to postgres;

