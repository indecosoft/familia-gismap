create function "getMedicine"("idClientP" integer, "idPersAsisocP" integer) returns json[]
    language plpgsql
as
$$
declare
	"idUserD" integer := (select u.id from "ingrijiriPaleative".users u where "idClient" = $1 and "idPersAsisoc" = $2);
begin
	return (select array(select row_to_json(r) from (select 
		d.id, 
		d.name boala, 
		(
			select array
			(
					select row_to_json(m) from (
						select dm.id, dm.name, dm.start "dataStart", dm.stop "dataStop", 
							(
								select array
								(
									select row_to_json(o) from 
									(
										select o.id, o.hour ora from "ingrijiriPaleative"."disease" d
											inner join "ingrijiriPaleative"."diseaseMed" dmo 
												on d.id = dmo."idDisease"
											inner join "ingrijiriPaleative"."diseaseHourMed" o
												on dmo.id = o."idMed"
											where o."idMed" = dm.id
									) o	
								)
							) ore from "ingrijiriPaleative"."disease" dd
								inner join "ingrijiriPaleative"."diseaseMed" dm
									on dd.id = dm."idDisease"
								where dm."idDisease" = d.id
					)m
			) medicamente
		) from "ingrijiriPaleative"."disease" d
		where "idUser" = "idUserD"
	) r));
end;
$$;

alter function "getMedicine"(integer, integer) owner to postgres;

