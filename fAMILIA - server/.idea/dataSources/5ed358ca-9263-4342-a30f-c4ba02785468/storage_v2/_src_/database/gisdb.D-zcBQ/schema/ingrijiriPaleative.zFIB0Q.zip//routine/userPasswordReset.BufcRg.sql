create function "userPasswordReset"(input_email character varying, input_new_password character varying) returns boolean
    language plpgsql
as
$$
DECLARE
      ref refcursor;
    BEGIN
    IF (SELECT COUNT(*) FROM "ingrijiriPaleative".users WHERE email = input_email) = 1 THEN
    
    	UPDATE "ingrijiriPaleative".users
		SET password = MD5(input_new_password || (SELECT salt from "ingrijiriPaleative".users WHERE email = input_email))
		WHERE email = input_email; 
        RETURN TRUE;
        
    ELSE
    	RETURN FALSE;
    END IF;
    END;


$$;

alter function "userPasswordReset"(varchar, varchar) owner to postgres;

